"""
screens/notes_screen.py
Notes management screens
Version: 1.300X
"""

import os
from kivy.clock import Clock
from kivy.metrics import dp, sp
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.animation import Animation
from kivy.graphics import Color, Rectangle
from kivy.core.window import Window

from kivymd.app import MDApp
from kivymd.uix.button import MDRaisedButton, MDIconButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel, MDIcon
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog

from utility import *
from calling import NoteManager


class NotesScreen(Screen):
    """Notes listing screen"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        main_layout = BoxLayout(orientation='vertical', padding=dp(15), spacing=dp(15))
        
        # Header
        header = BoxLayout(size_hint=(1, None), height=dp(70))
        
        back_btn = MDIconButton(
            icon='arrow-left',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            on_release=lambda x: setattr(self.manager, 'current', 'chat')
        )
        
        header_label = MDLabel(
            text='My Notes',
            font_style='H5',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        add_btn = MDIconButton(
            icon='plus',
            theme_text_color='Custom',
            text_color=(0.18, 0.8, 0.44, 1),
            on_release=self.add_note
        )
        
        header.add_widget(back_btn)
        header.add_widget(header_label)
        header.add_widget(add_btn)
        
        main_layout.add_widget(header)
        
        # Notes list
        self.notes_scroll = ScrollView(
            size_hint=(1, None),
            height=Window.height - dp(85),
            bar_width=dp(6),
            bar_color=(0.4, 0.8, 1, 0.5),
            bar_inactive_color=(0.3, 0.3, 0.3, 0.3)
        )
        
        self.notes_list = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            spacing=dp(12),
            padding=dp(5)
        )
        self.notes_list.bind(minimum_height=self.notes_list.setter('height'))
        self.notes_scroll.add_widget(self.notes_list)
        
        main_layout.add_widget(self.notes_scroll)
        self.add_widget(main_layout)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def on_enter(self):
        self.load_notes()
    
    def load_notes(self):
        self.notes_list.clear_widgets()
        
        app = MDApp.get_running_app()
        notes = NoteManager.get_notes(app.current_user['id'])
        
        if not notes:
            empty_label = MDLabel(
                text='No notes yet. Click + to add one!',
                size_hint_y=None,
                height=dp(120),
                halign='center',
                theme_text_color='Custom',
                text_color=(0.6, 0.6, 0.6, 1)
            )
            self.notes_list.add_widget(empty_label)
        else:
            for note in reversed(notes):
                note_card = self.create_note_card(note)
                self.notes_list.add_widget(note_card)
    
    def create_note_card(self, note):
        note_card = MDCard(
            orientation='vertical',
            size_hint_y=None,
            height=dp(120),
            padding=dp(18),
            spacing=dp(10),
            elevation=4,
            radius=[dp(18)],
            md_bg_color=(0.12, 0.12, 0.16, 1)
        )
        
        # Title
        title_box = BoxLayout(size_hint=(1, None), height=dp(38), spacing=dp(10))
        
        title_icon = MDIcon(
            icon='file-document',
            size_hint=(None, 1),
            width=dp(32),
            theme_text_color='Custom',
            text_color=(1, 0.84, 0, 1)
        )
        
        title_label = MDLabel(
            text=f"{note['title']}",
            markup=True,
            theme_text_color='Custom',
            text_color=(1, 0.84, 0, 1),
            font_style='Subtitle1',
            size_hint=(1, 1),
            bold=True
        )
        
        title_box.add_widget(title_icon)
        title_box.add_widget(title_label)
        note_card.add_widget(title_box)
        
        # Content preview
        preview = note['content'][:60] + ('...' if len(note['content']) > 60 else '')
        content_label = MDLabel(
            text=preview,
            size_hint=(1, None),
            height=dp(40),
            theme_text_color='Custom',
            text_color=(0.85, 0.85, 0.85, 1)
        )
        note_card.add_widget(content_label)
        
        # Bottom: date and buttons
        bottom_box = BoxLayout(size_hint=(1, None), height=dp(42))
        
        date_label = MDLabel(
            text=note.get('date_display', 'No date'),
            font_style='Caption',
            size_hint=(0.5, 1),
            theme_text_color='Custom',
            text_color=(0.6, 0.6, 0.6, 1)
        )
        
        btn_box = BoxLayout(size_hint=(0.5, 1), spacing=dp(5))
        
        view_btn = MDIconButton(
            icon='eye',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        view_btn.bind(on_press=lambda x, n=note: self.view_note(n))
        
        delete_btn = MDIconButton(
            icon='delete',
            theme_text_color='Custom',
            text_color=(0.9, 0.3, 0.3, 1)
        )
        delete_btn.bind(on_press=lambda x, n=note: self.delete_note(n))
        
        btn_box.add_widget(view_btn)
        btn_box.add_widget(delete_btn)
        
        bottom_box.add_widget(date_label)
        bottom_box.add_widget(btn_box)
        note_card.add_widget(bottom_box)
        
        # Entrance animation
        note_card.opacity = 0
        note_card.scale_value_x = 0.9
        note_card.scale_value_y = 0.9
        
        anim = Animation(
            opacity=1,
            scale_value_x=1,
            scale_value_y=1,
            duration=0.3,
            t='out_back'
        )
        anim.start(note_card)
        
        return note_card
    
    def view_note(self, note):
        sound_manager.play('click')
        app = MDApp.get_running_app()
        note_detail_screen = self.manager.get_screen('note_detail')
        note_detail_screen.current_note = note
        self.manager.current = 'note_detail'
    
    def add_note(self, instance):
        sound_manager.play('click')
        self.manager.current = 'chat'
        chat_screen = self.manager.get_screen('chat')
        chat_screen.start_note_creation()
    
    def delete_note(self, note):
        sound_manager.play('click')
        
        dialog = MDDialog(
            title='Confirm Delete',
            text=f'Delete note "{note["title"]}"?',
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: dialog.dismiss()
                ),
                MDRaisedButton(
                    text="DELETE",
                    md_bg_color=(0.8, 0.2, 0.2, 1),
                    elevation=4,
                    on_release=lambda x: self.confirm_delete(note, dialog)
                )
            ]
        )
        dialog.open()
    
    def confirm_delete(self, note, dialog):
        sound_manager.play('success')
        app = MDApp.get_running_app()
        NoteManager.delete_note(app.current_user['id'], note['id'])
        dialog.dismiss()
        self.load_notes()


class NoteDetailScreen(Screen):
    """Note detail/edit screen"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_note = None
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        layout = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(10))
        
        # Header
        header = BoxLayout(size_hint=(1, None), height=dp(60), padding=dp(5))
        
        back_btn = MDIconButton(
            icon='arrow-left',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            on_release=self.go_back
        )
        
        header_label = MDLabel(
            text='Note Details',
            font_style='H6',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        header.add_widget(back_btn)
        header.add_widget(header_label)
        header.add_widget(BoxLayout(size_hint=(None, 1), width=dp(48)))
        
        # Title input
        self.title_input = MDTextField(
            hint_text='Title',
            mode='round',
            size_hint=(1, None),
            height=dp(56),
            font_size=sp(16)
        )
        
        # Content scroll
        content_scroll = ScrollView(
            size_hint=(1, None),
            height=Window.height - dp(220),
            bar_width=dp(6),
            bar_color=(0.4, 0.8, 1, 0.5)
        )
        
        self.content_input = MDTextField(
            hint_text='Write your note content here...\n\nFormatting:\n*bold*\n_italic_\n• bullet points\n1. numbered lists',
            mode='fill',
            multiline=True,
            size_hint=(1, None),
            font_size=sp(15)
        )
        self.content_input.bind(minimum_height=self.content_input.setter('height'))
        content_scroll.add_widget(self.content_input)
        
        # Save button
        save_btn = MDRaisedButton(
            text='SAVE CHANGES',
            icon='content-save',
            size_hint=(1, None),
            height=dp(60),
            md_bg_color=(0.18, 0.8, 0.44, 1),
            elevation=8,
            font_size=sp(16)
        )
        save_btn.bind(on_press=self.save_note)
        
        layout.add_widget(header)
        layout.add_widget(self.title_input)
        layout.add_widget(content_scroll)
        layout.add_widget(save_btn)
        
        self.add_widget(layout)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def on_enter(self):
        if self.current_note:
            self.title_input.text = self.current_note['title']
            self.content_input.text = self.current_note['content']
            self.content_input.height = max(dp(500), self.content_input.minimum_height)
    
    def save_note(self, instance):
        sound_manager.play('success')
        
        app = MDApp.get_running_app()
        NoteManager.update_note(
            app.current_user['id'],
            self.current_note['id'],
            self.title_input.text,
            self.content_input.text
        )
        
        self.manager.current = 'notes'
    
    def go_back(self, instance):
        sound_manager.play('click')
        self.manager.current = 'notes'
