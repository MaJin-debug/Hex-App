"""
screens/settings_screen.py
Settings screen
Version: 1.300X
"""

from kivy.metrics import dp, sp
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle

from kivymd.app import MDApp
from kivymd.uix.button import MDRaisedButton, MDIconButton, MDFlatButton
from kivymd.uix.label import MDLabel, MDIcon
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.selectioncontrol import MDCheckbox
from kivymd.uix.boxlayout import MDBoxLayout

from utility import *


class SettingsScreen(Screen):
    """Settings screen"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        scroll = ScrollView()
        layout = MDBoxLayout(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(18),
            adaptive_height=True
        )
        
        # Header
        header = BoxLayout(size_hint=(1, None), height=dp(70))
        
        back_btn = MDIconButton(
            icon='arrow-left',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            on_release=lambda x: setattr(self.manager, 'current', 'chat')
        )
        
        header_label = MDLabel(
            text='Settings',
            font_style='H5',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        header.add_widget(back_btn)
        header.add_widget(header_label)
        header.add_widget(BoxLayout(size_hint=(None, 1), width=dp(48)))
        layout.add_widget(header)
        
        # Font size card
        font_card = MDCard(
            orientation='vertical',
            size_hint=(1, None),
            height=dp(150),
            padding=dp(18),
            elevation=4,
            spacing=dp(12),
            radius=[dp(18)],
            md_bg_color=(0.12, 0.12, 0.16, 1)
        )
        
        font_header = BoxLayout(size_hint=(1, None), height=dp(40), spacing=dp(12))
        
        font_icon = MDIcon(
            icon='format-size',
            size_hint=(None, 1),
            width=dp(40),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        
        font_title = MDLabel(
            text='Font Size',
            size_hint=(0.6, 1),
            font_style='Subtitle1',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        self.font_size_label = MDLabel(
            text='Medium',
            size_hint=(0.25, 1),
            halign='right',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            bold=True
        )
        
        font_header.add_widget(font_icon)
        font_header.add_widget(font_title)
        font_header.add_widget(self.font_size_label)
        font_card.add_widget(font_header)
        
        # Slider
        from kivymd.uix.slider import MDSlider
        self.font_slider = MDSlider(
            min=12,
            max=18,
            value=14,
            size_hint=(1, None),
            height=dp(45),
            color=(0.4, 0.8, 1, 1)
        )
        self.font_slider.bind(value=self.on_font_change)
        font_card.add_widget(self.font_slider)
        
        # Size labels
        size_row = BoxLayout(size_hint=(1, None), height=dp(28))
        size_row.add_widget(MDLabel(
            text='Small',
            font_style='Caption',
            halign='left',
            theme_text_color='Custom',
            text_color=(0.6, 0.6, 0.6, 1)
        ))
        size_row.add_widget(MDLabel(
            text='Medium',
            font_style='Caption',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.6, 0.6, 0.6, 1)
        ))
        size_row.add_widget(MDLabel(
            text='Large',
            font_style='Caption',
            halign='right',
            theme_text_color='Custom',
            text_color=(0.6, 0.6, 0.6, 1)
        ))
        font_card.add_widget(size_row)
        
        layout.add_widget(font_card)
        
        
        # Toggle cards
        toggle_items = [
            ('theme-light-dark', 'Dark Theme', True, self.toggle_theme, (1, 0.8, 0, 1)),
            ('lightbulb-on', 'Auto Suggestions', True, self.toggle_suggestions, (0.3, 1, 0.4, 1)),
            ('animation', 'Text Animation', True, self.toggle_animation, (0.4, 0.8, 1, 1))
        ]
        
        for icon, title, default, callback, icon_color in toggle_items:
            card = self.create_toggle_card(icon, title, default, callback, icon_color)
            layout.add_widget(card)
        
        # Action buttons
        help_btn = MDRaisedButton(
            text='HELP & GUIDE',
            icon='help-circle',
            size_hint=(1, None),
            height=dp(60),
            md_bg_color=(0.18, 0.8, 0.44, 1),
            elevation=6,
            font_size=sp(15)
        )
        help_btn.bind(on_press=self.show_help)
        layout.add_widget(help_btn)
        
        
        # Export button
        export_btn = MDRaisedButton(
            text='EXPORT DATA',
            icon='download',
            size_hint=(1, None),
            height=dp(60),
            md_bg_color=(0.15, 0.55, 0.95, 1),
            elevation=6,
            font_size=sp(15)
        )
        export_btn.bind(on_press=self.export_data)
        layout.add_widget(export_btn)
        
        scroll.add_widget(layout)
        self.add_widget(scroll)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def create_toggle_card(self, icon, title, default, callback, icon_color):
        card = MDCard(
            orientation='horizontal',
            size_hint=(1, None),
            height=dp(75),
            padding=dp(18),
            elevation=4,
            radius=[dp(18)],
            md_bg_color=(0.12, 0.12, 0.16, 1)
        )
        
        toggle_icon = MDIcon(
            icon=icon,
            size_hint=(None, 1),
            width=dp(40),
            theme_text_color='Custom',
            text_color=icon_color
        )
        
        toggle_label = MDLabel(
            text=title,
            size_hint=(0.6, 1),
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        toggle = MDCheckbox(
            active=default,
            size_hint=(0.25, 1),
            color_active=(0.4, 0.8, 1, 1)
        )
        toggle.bind(active=callback)
        
        card.add_widget(toggle_icon)
        card.add_widget(toggle_label)
        card.add_widget(toggle)
        
        return card
        
    def toggle_animation(self, checkbox, value):
        sound_manager.play('click')
        try:
            chat_screen = self.manager.get_screen('chat')
            chat_screen.animation_enabled = value
        except:
            pass
            
    def on_font_change(self, instance, value):
        if value < 13.5:
            size_text = 'Small'
        elif value < 16:
            size_text = 'Medium'
        else:
            size_text = 'Large'
        
        self.font_size_label.text = size_text
        
        app = MDApp.get_running_app()
        font_size = int(value)
        
        try:
            base_scale = font_size / 14.0
            
            app.theme_cls.font_styles['H1'] = ['Roboto', int(96 * base_scale), False, -1.5]
            app.theme_cls.font_styles['H2'] = ['Roboto', int(60 * base_scale), False, -0.5]
            app.theme_cls.font_styles['H3'] = ['Roboto', int(48 * base_scale), False, 0]
            app.theme_cls.font_styles['H4'] = ['Roboto', int(34 * base_scale), False, 0.25]
            app.theme_cls.font_styles['H5'] = ['Roboto', int(24 * base_scale), False, 0]
            app.theme_cls.font_styles['H6'] = ['Roboto', int(20 * base_scale), False, 0.15]
            app.theme_cls.font_styles['Subtitle1'] = ['Roboto', int(16 * base_scale), False, 0.15]
            app.theme_cls.font_styles['Subtitle2'] = ['Roboto', int(14 * base_scale), False, 0.1]
            app.theme_cls.font_styles['Body1'] = ['Roboto', int(16 * base_scale), False, 0.5]
            app.theme_cls.font_styles['Body2'] = ['Roboto', int(14 * base_scale), False, 0.25]
            app.theme_cls.font_styles['Button'] = ['Roboto', int(14 * base_scale), True, 1.25]
            app.theme_cls.font_styles['Caption'] = ['Roboto', int(12 * base_scale), False, 0.4]
            
            prefs = safe_load_json(USER_PREFS_FILE, {})
            user_id = app.current_user['id']
            if user_id not in prefs:
                prefs[user_id] = {}
            prefs[user_id]['font_size'] = font_size
            safe_save_json(USER_PREFS_FILE, prefs)
            
        except Exception as e:
            print(f"Font update error: {e}")
        
    def toggle_theme(self, checkbox, value):
        sound_manager.play('click')
        app = MDApp.get_running_app()
        app.theme_cls.theme_style = 'Dark' if value else 'Light'
        
    def toggle_suggestions(self, checkbox, value):
        sound_manager.play('click')
        chat_screen = self.manager.get_screen('chat')
        chat_screen.suggestions_enabled = value
    
    
    def export_data(self, instance):
        sound_manager.play('click')
        
        app = MDApp.get_running_app()
        success, result = export_data_external(app.current_user['id'])
        
        if success:
            sound_manager.play('success')
            dialog = MDDialog(
                title='Success',
                text=f'Data exported to:\n{result}',
                buttons=[
                    MDFlatButton(
                        text="OK",
                        theme_text_color='Custom',
                        text_color=(0.4, 0.8, 1, 1),
                        on_release=lambda x: dialog.dismiss()
                    )
                ]
            )
            dialog.open()
        else:
            sound_manager.play('error')
            show_error_toast(f"Export failed: {result}")
            
            
    def show_help(self, instance):
        sound_manager.play('click')
    
        help_text = """HEX - Your Second Brain

🧠 WHAT IS HEX?
Personal knowledge storage system that learns how you speak and remembers everything you teach it.

⌨️ BASIC COMMANDS:
/teach - Open knowledge storage screen
/overview <topic> - View all info about a topic
/add_note - Create a quick note
/remind <what> - Set a reminder
/bye - Exit the app

💾 STORING KNOWLEDGE:
1. Click Menu > Store Knowledge (or type /teach)
2. Enter your question
3. Click "WRITE ANSWER" to type the answer
4. Check "I am sure" if you're confident
5. Check "Add to HEX knowledge" to share with all users
6. Click "SAVE KNOWLEDGE"

🧠 BRAIN BUTTON:
Bottom-left brain button controls HEX knowledge:
• Blue (ON) = Uses both your knowledge and HEX knowledge
• Gray (OFF) = Uses only your personal knowledge

🔍 HOW MATCHING WORKS:
1. Exact Match - Shows answer immediately
2. Fuzzy Match - Shows answer, asks "Did you mean...?"
3. Keyword Match - Shows answer, asks "Did you mean...?"
4. No Match - Offers to store new knowledge

✏️ SPELLING LEARNING:
When HEX asks "Did you mean X?":
• YES = Learns your spelling variation
• NO = Never suggests this match again

Next time you use the same spelling, HEX understands automatically.

🎯 DYNAMIC PLACEHOLDERS:
Use these in answers for dynamic content:
{user_name} - Your name
{current_date} - Today's date
{current_time} - Current time
{greeting} - Time-based greeting
{current_year} - Current year
{current_month} - Current month
{current_day} - Current day
{day_of_week} - Day of week

Example: "Hello {user_name}, today is {current_date}"

📊 OVERVIEW FEATURE:
Type: /overview <topic>
Shows all related knowledge and notes about that topic.
Example: /overview python

📝 NOTES SYSTEM:
Quick notes for temporary information:
1. Menu > My Notes (or type /add_note)
2. Enter title
3. Enter content
4. View all notes in My Notes screen

⏰ REMINDERS:
Set time-based reminders:
Type: /remind buy groceries
Then specify time: 5pm, in 2 hours, 17:30

💫 IMPORT/EXPORT:
Export: Settings > Export Knowledge
• Backs up to local folder
Import: Store Knowledge > Import Knowledge
• Replace knowledge from JSON file
• WARNING: Replaces all existing knowledge

🎨 CHAT BUBBLE LIMIT:
HEX keeps last 30 chat bubbles to maintain performance.
Older messages are automatically removed.

👥 MULTI-USER:
• Each user has separate knowledge
• Switch accounts in login screen
• HEX knowledge is shared across all users

💡 TIPS:
• User knowledge is prioritized over HEX knowledge
• Mark answers as "I am sure" only when confident
• Use specific questions for better matching
• Export your knowledge regularly as backup

🔧 TROUBLESHOOTING:
• If HEX doesn't understand, teach it the exact phrase
• If matching is wrong, click NO to reject
• Check brain button status (blue = ON, gray = OFF)
• Use Settings to adjust font size and preferences"""
    
        from kivy.uix.scrollview import ScrollView
        from kivy.uix.label import Label
        from kivy.metrics import dp
        from kivymd.uix.dialog import MDDialog
        from kivymd.uix.button import MDFlatButton
    
        # Create ScrollView
        scroll = ScrollView(
            size_hint=(1, 1),
            do_scroll_x=False,
            bar_width=dp(8),
            bar_color=(0.4, 0.8, 1, 0.7),
            bar_inactive_color=(0.3, 0.3, 0.3, 0.5)
        )
    
        # Create Label with proper sizing behavior
        help_label = Label(
            text=help_text,
            size_hint_y=None,
            height=dp(200),  # starting value - will be updated
            text_size=(None, None),  # will be set in binding
            halign='left',
            valign='top',
            padding=[dp(24), dp(24), dp(24), dp(24)],
            color=(0.95, 0.95, 0.98, 1),
            font_size=dp(15),          # readable size
            line_height=1.4,
            markup=False
        )
    
        # === Bindings - this is the reliable way ===
        # 1. Update text_size based on available width (important in dialog)
        def update_text_size(instance, width):
            help_label.text_size = (width - dp(48), None)
    
        help_label.bind(width=update_text_size)
    
        # 2. Update height when texture (text) size changes
        def update_height(instance, texture_size):
            help_label.height = texture_size[1] + dp(40)  # small padding
    
        help_label.bind(texture_size=update_height)
    
        # Force initial text_size update once width is known
        # (often needed the first time)
        if help_label.width > 100:  # avoid nonsense small values
            help_label.text_size = (help_label.width - dp(48), None)
    
        # Add label to scrollview
        scroll.add_widget(help_label)
    
        # Create dialog
        self.help_dialog = MDDialog(
            title="📖 Help & Guide",
            type="custom",
            content_cls=scroll,
            size_hint=(0.92, 0.88),
            auto_dismiss=False,  # better UX in this case
            buttons=[
                MDFlatButton(
                    text="CLOSE",
                    theme_text_color="Custom",
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: self.help_dialog.dismiss()
                )
            ]
        )
    
        # Optional: give content some minimum height if very small screen
        if hasattr(self.help_dialog, 'content_cls'):
            self.help_dialog.content_cls.min_height = dp(400)
    
        self.help_dialog.open()
