"""
screens/auth_screens.py
Registration and Login screens
Version: 1.300X
"""

import os
from kivy.clock import Clock
from kivy.metrics import dp, sp
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.animation import Animation
from kivy.graphics import Color, Rectangle

from kivymd.app import MDApp
from kivymd.uix.button import MDRaisedButton, MDIconButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel, MDIcon
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.boxlayout import MDBoxLayout

from utility import *


class RegisterScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        scroll = ScrollView()
        layout = MDBoxLayout(
            orientation='vertical',
            padding=dp(25),
            spacing=dp(18),
            adaptive_height=True
        )
        
        # Header
        header = BoxLayout(size_hint=(1, None), height=dp(80), spacing=dp(15))
        
        header_icon = MDIcon(
            icon='account-plus',
            font_size=sp(42),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        
        header_label = MDLabel(
            text='Create Account',
            font_style='H4',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        header.add_widget(header_icon)
        header.add_widget(header_label)
        layout.add_widget(header)
        
        # Input fields
        self.name_input = MDTextField(
            hint_text='Full Name',
            icon_left='account',
            required=True,
            size_hint=(1, None),
            height=dp(56),
            mode='round',
            font_size=sp(16)
        )
        
        self.mobile_input = MDTextField(
            hint_text='Mobile (optional)',
            icon_left='phone',
            size_hint=(1, None),
            height=dp(56),
            mode='round',
            font_size=sp(16)
        )
        
        self.place_input = MDTextField(
            hint_text='Place (optional)',
            icon_left='map-marker',
            size_hint=(1, None),
            height=dp(56),
            mode='round',
            font_size=sp(16)
        )
        
        self.password_input = MDTextField(
            hint_text='Password',
            icon_left='lock',
            password=True,
            required=True,
            size_hint=(1, None),
            height=dp(56),
            mode='round',
            font_size=sp(16)
        )
        
        # Info card
        info_card = MDCard(
            orientation='horizontal',
            size_hint=(1, None),
            height=dp(65),
            padding=dp(15),
            elevation=2,
            radius=[dp(15)],
            md_bg_color=(0.15, 0.15, 0.2, 1)
        )
        
        info_icon = MDIcon(
            icon='information',
            size_hint=(None, 1),
            width=dp(30),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        
        warning = MDLabel(
            text='Password is for offline use only',
            font_style='Caption',
            theme_text_color='Custom',
            text_color=(0.7, 0.7, 0.7, 1),
            size_hint=(1, 1)
        )
        
        info_card.add_widget(info_icon)
        info_card.add_widget(warning)
        
        layout.add_widget(self.name_input)
        layout.add_widget(self.mobile_input)
        layout.add_widget(self.place_input)
        layout.add_widget(self.password_input)
        layout.add_widget(info_card)
        
        # Create button
        create_btn = MDRaisedButton(
            text='CREATE ACCOUNT',
            size_hint=(1, None),
            height=dp(56),
            md_bg_color=(0.15, 0.55, 0.95, 1),
            icon='account-check',
            elevation=6,
            font_size=sp(16)
        )
        create_btn.bind(on_press=self.create_account)
        layout.add_widget(create_btn)
        
        # Back button
        back_btn = MDFlatButton(
            text='Already have an account? Login',
            size_hint=(1, None),
            height=dp(48),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        back_btn.bind(on_press=lambda x: self.check_and_go_login())
        layout.add_widget(back_btn)
        
        scroll.add_widget(layout)
        self.add_widget(scroll)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def check_and_go_login(self):
        sound_manager.play('click')
        users = load_json(USERS_FILE, {'users': []})
        if users.get('users'):
            self.manager.current = 'login'
    
    def create_account(self, instance):
        sound_manager.play('click')
        
        name = self.name_input.text.strip()
        password = self.password_input.text.strip()
        
        if not name or not password:
            sound_manager.play('error')
            self.show_dialog('Error', 'Name and Password are required!')
            return
        
        users = load_json(USERS_FILE, {'users': []})
        user_id = f"u{len(users['users']) + 1:03d}"
        
        new_user = {
            'id': user_id,
            'name': name,
            'mobile': self.mobile_input.text.strip(),
            'place': self.place_input.text.strip(),
            'password_hash': hash_password(password)
        }
        
        users['users'].append(new_user)
        save_json(USERS_FILE, users)
        
        # Initialize user files
        user_knowledge_file = os.path.join(DATA_DIR, f'knowledge_user_{user_id}.json')
        save_json(user_knowledge_file, {'knowledge': []})
        
        if not os.path.exists(HEX_KNOWLEDGE_FILE):
            save_json(HEX_KNOWLEDGE_FILE, {'knowledge': []})
        if not os.path.exists(SPELLING_MAP_FILE):
            save_json(SPELLING_MAP_FILE, {})
        if not os.path.exists(SPELLING_REJECTED_FILE):
            save_json(SPELLING_REJECTED_FILE, {})
        if not os.path.exists(NOTES_FILE):
            save_json(NOTES_FILE, {})
        if not os.path.exists(TASKS_FILE):
            save_json(TASKS_FILE, {})
        if not os.path.exists(GALLERY_FILE):
            save_json(GALLERY_FILE, {})
        
        sound_manager.play('success')
        MDApp.get_running_app().current_user = new_user
        self.manager.current = 'chat'
    
    def show_dialog(self, title, message):
        dialog = MDDialog(
            title=title,
            text=message,
            buttons=[
                MDFlatButton(
                    text="OK",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()


class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        scroll = ScrollView()
        layout = MDBoxLayout(
            orientation='vertical',
            padding=dp(25),
            spacing=dp(20),
            adaptive_height=True
        )
        
        # Header
        header = BoxLayout(
            size_hint=(1, None),
            height=dp(120),
            orientation='vertical',
            spacing=dp(15)
        )
        
        brain_icon = MDIcon(
            icon='brain',
            font_size=sp(70),
            halign='center',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        
        self.welcome_label = MDLabel(
            text='Welcome Back',
            font_style='H4',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        header.add_widget(brain_icon)
        header.add_widget(self.welcome_label)
        layout.add_widget(header)
        
        # Password input
        self.password_input = MDTextField(
            hint_text='Enter Password',
            icon_left='lock',
            password=True,
            size_hint=(1, None),
            height=dp(56),
            mode='round',
            font_size=sp(16)
        )
        layout.add_widget(self.password_input)
        
        # Login button
        login_btn = MDRaisedButton(
            text='LOGIN',
            size_hint=(1, None),
            height=dp(56),
            md_bg_color=(0.15, 0.55, 0.95, 1),
            icon='login',
            elevation=6,
            font_size=sp(16)
        )
        login_btn.bind(on_press=self.login)
        layout.add_widget(login_btn)
        
        # Switch and sign up buttons
        switch_btn = MDFlatButton(
            text='Switch Account',
            size_hint=(1, None),
            height=dp(52),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        switch_btn.bind(on_press=self.switch_account)
        layout.add_widget(switch_btn)
        
        signup_btn = MDFlatButton(
            text='Create New Account',
            size_hint=(1, None),
            height=dp(52),
            theme_text_color='Custom',
            text_color=(0.18, 0.8, 0.44, 1)
        )
        signup_btn.bind(on_press=lambda x: setattr(self.manager, 'current', 'register'))
        layout.add_widget(signup_btn)
        
        scroll.add_widget(layout)
        self.add_widget(scroll)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def on_enter(self):
        users = load_json(USERS_FILE, {'users': []})
        if users.get('users'):
            app = MDApp.get_running_app()
            if hasattr(app, 'current_user') and app.current_user:
                user_name = app.current_user['name']
            else:
                user_name = users['users'][0]['name']
                app.current_user = users['users'][0]
            
            self.welcome_label.text = f'Welcome {user_name}'
    
    def login(self, instance):
        sound_manager.play('click')
        
        password = self.password_input.text.strip()
        app = MDApp.get_running_app()
        
        if hash_password(password) == app.current_user['password_hash']:
            sound_manager.play('success')
            self.manager.current = 'chat'
        else:
            sound_manager.play('error')
            self.show_dialog('Error', 'Incorrect password!')
    
    def switch_account(self, instance):
        sound_manager.play('click')
        users = load_json(USERS_FILE, {'users': []})
        
        content = MDBoxLayout(
            orientation='vertical',
            spacing=dp(12),
            padding=dp(15),
            adaptive_height=True
        )
        
        for user in users['users']:
            btn = MDRaisedButton(
                text=user['name'],
                size_hint_y=None,
                height=dp(56),
                icon='account',
                md_bg_color=(0.15, 0.55, 0.95, 1),
                elevation=4,
                on_release=lambda x, u=user: self.select_user(u)
            )
            content.add_widget(btn)
        
        self.switch_dialog = MDDialog(
            title='Select Account',
            type='custom',
            content_cls=content,
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: self.switch_dialog.dismiss()
                )
            ]
        )
        self.switch_dialog.open()
    
    def select_user(self, user):
        sound_manager.play('click')
        MDApp.get_running_app().current_user = user
        self.switch_dialog.dismiss()
        self.on_enter()
    
    def show_dialog(self, title, message):
        dialog = MDDialog(
            title=title,
            text=message,
            buttons=[
                MDFlatButton(
                    text="OK",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()
