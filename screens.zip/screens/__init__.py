"""
screens/__init__.py
Screen modules for HEX app
Version: 1.300X
"""

from screens.splash_screen import SplashScreen
from screens.auth_screens import RegisterScreen, LoginScreen
from screens.chat_screen import ChatScreen
from screens.knowledge_screens import AddKnowledgeScreen, EditKnowledgeScreen
from screens.notes_screen import NotesScreen, NoteDetailScreen
from screens.settings_screen import SettingsScreen
from screens.account_screen import AccountScreen
from screens.gallery_screen import GalleryScreen, AddMemoryScreen

__all__ = [
    'SplashScreen',
    'RegisterScreen',
    'LoginScreen',
    'ChatScreen',
    'AddKnowledgeScreen',
    'EditKnowledgeScreen',
    'NotesScreen',
    'NoteDetailScreen',
    'SettingsScreen',
    'AccountScreen',
    'GalleryScreen',
    'AddMemoryScreen'
]
