"""
screens/knowledge_screens.py  
Add and Edit Knowledge screens
Version: 1.300X
"""

import os
from datetime import datetime
from kivy.clock import Clock
from kivy.metrics import dp, sp
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle
from kivy.core.window import Window
from kivy.animation import Animation

from kivymd.app import MDApp
from kivymd.uix.button import MDRaisedButton, MDIconButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel, MDIcon
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.selectioncontrol import MDCheckbox
from kivymd.uix.boxlayout import MDBoxLayout

from utility import *


class AddKnowledgeScreen(Screen):
    """Add new knowledge screen"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        main_layout = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(10))
        
        # Header
        header = BoxLayout(size_hint=(1, 0.08), padding=dp(5))
        
        back_btn = MDIconButton(
            icon='arrow-left',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            on_release=lambda x: setattr(self.manager, 'current', 'chat')
        )
        
        header_label = MDLabel(
            text='Store Knowledge',
            font_style='H6',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        edit_btn = MDIconButton(
            icon='pencil',
            theme_text_color='Custom',
            text_color=(1, 0.6, 0, 1),
            on_release=lambda x: setattr(self.manager, 'current', 'edit_knowledge')
        )
        
        header.add_widget(back_btn)
        header.add_widget(header_label)
        header.add_widget(edit_btn)
        
        # Scrollable content
        scroll = ScrollView(size_hint=(1, 0.92))
        layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(15),
            padding=dp(15),
            adaptive_height=True
        )
        
        # Question
        q_label = MDLabel(
            text='Question:',
            size_hint=(1, None),
            height=dp(35),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            bold=True
        )
        layout.add_widget(q_label)
        
        self.question_input = MDTextField(
            hint_text='What do you want to ask?',
            mode='round',
            size_hint=(1, None),
            height=dp(56),
            font_size=sp(15),
            multiline=False
        )
        layout.add_widget(self.question_input)
        
        # Answer
        a_label = MDLabel(
            text='Answer:',
            size_hint=(1, None),
            height=dp(35),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            bold=True
        )
        layout.add_widget(a_label)
        
        # Answer text field with better height
        answer_scroll = ScrollView(
            size_hint=(1, None),
            height=dp(200),
            bar_width=dp(6),
            bar_color=(0.4, 0.8, 1, 0.5)
        )
        
        self.answer_input = MDTextField(
            hint_text='Write your detailed answer here...\n\nFormatting:\n*bold*\n_italic_\n• bullet points\n1. numbered lists\n\nPlaceholders:\n{user_name}\n{current_date}\n{current_time}\n{greeting}',
            mode='fill',
            multiline=True,
            size_hint=(1, None),
            font_size=sp(15)
        )
        self.answer_input.bind(minimum_height=self.answer_input.setter('height'))
        answer_scroll.add_widget(self.answer_input)
        
        layout.add_widget(answer_scroll)
        
        # Options card
        options_card = MDCard(
            orientation='vertical',
            size_hint=(1, None),
            height=dp(130),
            padding=dp(15),
            spacing=dp(10),
            elevation=4,
            radius=[dp(18)],
            md_bg_color=(0.12, 0.12, 0.16, 1)
        )
        
        # Sureness checkbox
        sure_box = BoxLayout(size_hint=(1, None), height=dp(50), spacing=dp(12))
        
        sure_icon = MDIcon(
            icon='check-decagram',
            size_hint=(None, 1),
            width=dp(35),
            theme_text_color='Custom',
            text_color=(0.3, 1, 0.4, 1)
        )
        
        sure_label = MDLabel(
            text='I am sure about this',
            size_hint=(0.6, 1),
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        self.sure_checkbox = MDCheckbox(
            size_hint=(0.25, 1),
            color_active=(0.3, 1, 0.4, 1)
        )
        
        sure_box.add_widget(sure_icon)
        sure_box.add_widget(sure_label)
        sure_box.add_widget(self.sure_checkbox)
        options_card.add_widget(sure_box)
        
        # HEX knowledge checkbox
        hex_box = BoxLayout(size_hint=(1, None), height=dp(50), spacing=dp(12))
        
        hex_icon = MDIcon(
            icon='brain',
            size_hint=(None, 1),
            width=dp(35),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        
        hex_label = MDLabel(
            text='Add to HEX knowledge',
            size_hint=(0.6, 1),
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        self.hex_checkbox = MDCheckbox(
            size_hint=(0.25, 1),
            color_active=(0.4, 0.8, 1, 1)
        )
        self.hex_checkbox.bind(active=self.show_hex_warning)
        
        hex_box.add_widget(hex_icon)
        hex_box.add_widget(hex_label)
        hex_box.add_widget(self.hex_checkbox)
        options_card.add_widget(hex_box)
        
        layout.add_widget(options_card)
        
        # Save button
        save_btn = MDRaisedButton(
            text='SAVE KNOWLEDGE',
            icon='content-save',
            size_hint=(1, None),
            height=dp(60),
            md_bg_color=(0.18, 0.8, 0.44, 1),
            elevation=8,
            font_size=sp(16)
        )
        save_btn.bind(on_press=self.save_knowledge)
        layout.add_widget(save_btn)
        
        scroll.add_widget(layout)
        main_layout.add_widget(header)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def on_enter(self):
        app = MDApp.get_running_app()
        if hasattr(app, 'pending_teach_question') and app.pending_teach_question:
            self.question_input.text = app.pending_teach_question
            app.pending_teach_question = None
        if hasattr(app, 'pending_answer') and app.pending_answer:
            self.answer_input.text = app.pending_answer
            app.pending_answer = None
    
    def show_hex_warning(self, checkbox, value):
        if value:
            sound_manager.play('click')
            dialog = MDDialog(
                title='Warning',
                text='This will be available to all users of this device.',
                buttons=[
                    MDFlatButton(
                        text="I UNDERSTAND",
                        theme_text_color='Custom',
                        text_color=(0.4, 0.8, 1, 1),
                        on_release=lambda x: dialog.dismiss()
                    )
                ]
            )
            dialog.open()
    
    def save_knowledge(self, instance):
        sound_manager.play('click')
        
        question = self.question_input.text.strip()
        answer = self.answer_input.text.strip()
        
        if not question or not answer:
            sound_manager.play('error')
            self.show_dialog('Error', 'Please fill question and answer!')
            return
        
        app = MDApp.get_running_app()
        user_id = app.current_user['id']
        
        if self.hex_checkbox.active:
            filepath = HEX_KNOWLEDGE_FILE
        else:
            filepath = os.path.join(DATA_DIR, f'knowledge_user_{user_id}.json')
        
        knowledge = load_json(filepath, {'knowledge': []})
        
        new_entry = {
            'question': question,
            'answer': answer,
            'sure': self.sure_checkbox.active,
            'timestamp': datetime.now().isoformat()
        }
        
        knowledge['knowledge'].append(new_entry)
        save_json(filepath, knowledge)
        
        sound_manager.play('success')
        
        self.question_input.text = ''
        self.answer_input.text = ''
        self.sure_checkbox.active = False
        self.hex_checkbox.active = False
        
        dialog = MDDialog(
            title='Success',
            text='Knowledge saved successfully!',
            buttons=[
                MDFlatButton(
                    text="OK",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()
        Clock.schedule_once(lambda dt: dialog.dismiss(), 1.5)
    
    def show_dialog(self, title, message):
        dialog = MDDialog(
            title=title,
            text=message,
            buttons=[
                MDFlatButton(
                    text="OK",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()


class EditKnowledgeScreen(Screen):
    """Edit existing knowledge screen"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_items = []
        self.shown_count = 0
        self.edit_item = None
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        layout = BoxLayout(orientation='vertical', spacing=dp(10), padding=dp(10))
        
        # Header
        header = BoxLayout(size_hint=(1, 0.08), padding=dp(5))
        
        back_btn = MDIconButton(
            icon='arrow-left',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            on_release=lambda x: setattr(self.manager, 'current', 'add_knowledge')
        )
        
        header_label = MDLabel(
            text='Edit Knowledge',
            font_style='H6',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        header.add_widget(back_btn)
        header.add_widget(header_label)
        header.add_widget(BoxLayout(size_hint=(None, 1), width=dp(48)))
        layout.add_widget(header)
        
        # Search box
        search_box = BoxLayout(size_hint=(1, 0.08), spacing=dp(8))
        
        self.search_input = MDTextField(
            hint_text='Search knowledge...',
            mode='round',
            icon_left='magnify',
            size_hint=(0.85, 1),
            font_size=sp(15)
        )
        self.search_input.bind(text=self.search_knowledge)
        
        search_btn = MDIconButton(
            icon='magnify',
            size_hint=(0.15, 1),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        search_btn.bind(on_press=lambda x: self.search_knowledge(None, self.search_input.text))
        
        search_box.add_widget(self.search_input)
        search_box.add_widget(search_btn)
        layout.add_widget(search_box)
        
        # Knowledge list
        self.knowledge_scroll = ScrollView(
            size_hint=(1, 0.84),
            bar_width=dp(6),
            bar_color=(0.4, 0.8, 1, 0.5),
            bar_inactive_color=(0.3, 0.3, 0.3, 0.3)
        )
        
        self.knowledge_list = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            spacing=dp(8),
            padding=dp(5)
        )
        self.knowledge_list.bind(minimum_height=self.knowledge_list.setter('height'))
        self.knowledge_scroll.add_widget(self.knowledge_list)
        layout.add_widget(self.knowledge_scroll)
        
        self.add_widget(layout)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def on_enter(self):
        Clock.schedule_once(lambda dt: self.load_knowledge_list(), 0.1)
    
    def search_knowledge(self, instance, value):
        Clock.schedule_once(lambda dt: self.load_knowledge_list(search_term=value), 0.1)
    
    def load_knowledge_list(self, search_term=''):
        self.knowledge_list.clear_widgets()
        
        loading = MDLabel(
            text='Loading...',
            size_hint_y=None,
            height=dp(60),
            halign='center',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        self.knowledge_list.add_widget(loading)
        
        Clock.schedule_once(lambda dt: self._do_load_knowledge(search_term), 0.05)
    
    def _do_load_knowledge(self, search_term=''):
        self.knowledge_list.clear_widgets()
        
        app = MDApp.get_running_app()
        user_id = app.current_user['id']
        
        user_knowledge = load_json(
            os.path.join(DATA_DIR, f'knowledge_user_{user_id}.json'),
            {'knowledge': []}
        )
        hex_knowledge = load_json(HEX_KNOWLEDGE_FILE, {'knowledge': []})
    
        all_items = []
        for item in user_knowledge['knowledge']:
            all_items.append({**item, 'source': 'user'})
        for item in hex_knowledge['knowledge']:
            all_items.append({**item, 'source': 'hex'})
    
        # Filter
        if search_term:
            filtered_items = [
                item for item in all_items
                if search_term.lower() in item['question'].lower() or
                   search_term.lower() in item['answer'].lower()
            ]
        else:
            filtered_items = all_items
    
        filtered_items.sort(key=lambda x: x.get('sure', False), reverse=True)
    
        if not filtered_items:
            empty_label = MDLabel(
                text='No knowledge found',
                size_hint_y=None,
                height=dp(80),
                halign='center',
                theme_text_color='Custom',
                text_color=(0.6, 0.6, 0.6, 1)
            )
            self.knowledge_list.add_widget(empty_label)
        else:
            self.current_items = filtered_items
            self.shown_count = 0
            self.show_items()
    
    def show_items(self):
        start = self.shown_count
        end = min(start + 10, len(self.current_items))
    
        for item in self.current_items[start:end]:
            card = MDCard(
                orientation='horizontal',
                size_hint_y=None,
                height=dp(65),
                padding=dp(12),
                spacing=dp(10),
                elevation=3,
                radius=[dp(15)],
                md_bg_color=(0.12, 0.12, 0.16, 1)
            )
            
            # Status indicator
            status_icon = MDIcon(
                icon='check-circle' if item.get('sure', False) else 'alert-circle',
                size_hint=(None, 1),
                width=dp(30),
                theme_text_color='Custom',
                text_color=(0.3, 1, 0.4, 1) if item.get('sure', False) else (1, 0.6, 0, 1)
            )
            
            # Question text
            q_text = item['question'][:50] + ('...' if len(item['question']) > 50 else '')
            
            q_btn = MDFlatButton(
                text=q_text,
                size_hint=(1, 1),
                theme_text_color='Custom',
                text_color=(0.9, 0.9, 0.9, 1)
            )
            q_btn.bind(on_press=lambda x, i=item: self.show_item_details(i))
            
            # Source indicator
            source_icon = MDIcon(
                icon='brain' if item['source'] == 'hex' else 'account',
                size_hint=(None, 1),
                width=dp(30),
                theme_text_color='Custom',
                text_color=(0.4, 0.8, 1, 1) if item['source'] == 'hex' else (0.6, 0.4, 0.8, 1)
            )
            
            card.add_widget(status_icon)
            card.add_widget(q_btn)
            card.add_widget(source_icon)
            
            card.opacity = 0
            card.scale_value_x = 0.95
            card.scale_value_y = 0.95
            
            self.knowledge_list.add_widget(card)
            
            anim = Animation(
                opacity=1,
                scale_value_x=1,
                scale_value_y=1,
                duration=0.25,
                t='out_quad'
            )
            Clock.schedule_once(lambda dt, c=card, a=anim: a.start(c), 0.05 * (end - start))
    
        self.shown_count = end
    
    def show_item_details(self, item):
        sound_manager.play('click')
        self.edit_item = item
    
        content = MDBoxLayout(
            orientation='vertical',
            spacing=dp(12),
            padding=dp(15),
            adaptive_height=True
        )
        
        # Question
        q_label = MDLabel(
            text=f"Q: {item['question']}",
            markup=True,
            size_hint_y=None,
            height=dp(70),
            text_size=(Window.width * 0.8, None),
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        q_label.bind(texture_size=q_label.setter('size'))
        content.add_widget(q_label)
    
        # Answer in scroll
        a_scroll = ScrollView(
            size_hint=(1, None),
            height=dp(160),
            bar_width=dp(6),
            bar_color=(0.4, 0.8, 1, 0.5)
        )
        
        a_label = MDLabel(
            text=f"A: {item['answer']}",
            markup=True,
            size_hint_y=None,
            text_size=(Window.width * 0.7, None),
            theme_text_color='Custom',
            text_color=(0.85, 0.85, 0.85, 1)
        )
        a_label.bind(texture_size=a_label.setter('size'))
        a_scroll.add_widget(a_label)
        content.add_widget(a_scroll)
    
        # Action buttons
        btn_box = BoxLayout(size_hint=(1, None), height=dp(56), spacing=dp(12))
    
        edit_btn = MDRaisedButton(
            text='EDIT',
            size_hint=(0.5, 1),
            md_bg_color=(0.15, 0.55, 0.95, 1),
            icon='pencil',
            elevation=6
        )
        edit_btn.bind(on_press=lambda x: self.edit_selected())
        
        delete_btn = MDRaisedButton(
            text='DELETE',
            size_hint=(0.5, 1),
            md_bg_color=(0.8, 0.2, 0.2, 1),
            icon='delete',
            elevation=6
        )
        delete_btn.bind(on_press=lambda x: self.delete_item(item))
    
        btn_box.add_widget(edit_btn)
        btn_box.add_widget(delete_btn)
        content.add_widget(btn_box)
        
        self.details_dialog = MDDialog(
            title='Knowledge Details',
            type='custom',
            content_cls=content,
            size_hint=(0.92, None),
            height=dp(480),
            buttons=[
                MDFlatButton(
                    text="CLOSE",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: self.details_dialog.dismiss()
                )
            ]
        )
        self.details_dialog.open()
    
    def edit_selected(self):
        sound_manager.play('click')
        self.details_dialog.dismiss()
        
        app = MDApp.get_running_app()
        app.pending_teach_question = self.edit_item['question']
        app.pending_answer = self.edit_item['answer']
        
        # Delete the old entry
        user_id = app.current_user['id']
        
        if self.edit_item['source'] == 'user':
            filepath = os.path.join(DATA_DIR, f'knowledge_user_{user_id}.json')
        else:
            filepath = HEX_KNOWLEDGE_FILE
        
        knowledge = load_json(filepath, {'knowledge': []})
        
        knowledge['knowledge'] = [
            k for k in knowledge['knowledge']
            if k['question'] != self.edit_item['question'] or k['answer'] != self.edit_item['answer']
        ]
        
        save_json(filepath, knowledge)
        
        self.manager.current = 'add_knowledge'
    
    def delete_item(self, item):
        sound_manager.play('click')
        self.details_dialog.dismiss()
        
        dialog = MDDialog(
            title='Confirm Delete',
            text=f'Delete this?\n"{item["question"]}"',
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: dialog.dismiss()
                ),
                MDRaisedButton(
                    text="DELETE",
                    md_bg_color=(0.8, 0.2, 0.2, 1),
                    elevation=6,
                    on_release=lambda x: self.confirm_delete(item, dialog)
                )
            ]
        )
        dialog.open()
    
    def confirm_delete(self, item, dialog):
        sound_manager.play('success')
        app = MDApp.get_running_app()
        user_id = app.current_user['id']
        
        if item['source'] == 'user':
            filepath = os.path.join(DATA_DIR, f'knowledge_user_{user_id}.json')
        else:
            filepath = HEX_KNOWLEDGE_FILE
        
        knowledge = load_json(filepath, {'knowledge': []})
        
        knowledge['knowledge'] = [
            k for k in knowledge['knowledge']
            if k['question'] != item['question'] or k['answer'] != item['answer']
        ]
        
        save_json(filepath, knowledge)
        dialog.dismiss()
        Clock.schedule_once(lambda dt: self.load_knowledge_list(), 0.1)
