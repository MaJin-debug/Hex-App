"""
screens/gallery_screen.py
Gallery screens for storing memories with images
Version: 1.300X
"""

import os
import shutil
import uuid
from datetime import datetime

from kivy.clock import Clock
from kivy.metrics import dp, sp
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import Image as KivyImage
from kivy.animation import Animation
from kivy.graphics import Color, Rectangle
from kivy.core.window import Window

from kivymd.app import MDApp
from kivymd.uix.button import MDRaisedButton, MDIconButton, MDFlatButton, MDFloatingActionButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel, MDIcon
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.boxlayout import MDBoxLayout

from utility import *





class GalleryScreen(Screen):
    """Gallery listing screen"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        main_layout = BoxLayout(orientation='vertical', padding=dp(15), spacing=dp(15))
        
        # Header
        header = BoxLayout(size_hint=(1, None), height=dp(70))
        
        back_btn = MDIconButton(
            icon='arrow-left',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            on_release=lambda x: setattr(self.manager, 'current', 'chat')
        )
        
        header_label = MDLabel(
            text='Gallery',
            font_style='H5',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        add_btn = MDIconButton(
            icon='plus',
            theme_text_color='Custom',
            text_color=(0.18, 0.8, 0.44, 1),
            on_release=lambda x: setattr(self.manager, 'current', 'add_memory')
        )
        
        header.add_widget(back_btn)
        header.add_widget(header_label)
        header.add_widget(add_btn)
        
        main_layout.add_widget(header)
        
        # Gallery grid
        self.gallery_scroll = ScrollView(
            size_hint=(1, None),
            height=Window.height - dp(85),
            bar_width=dp(6),
            bar_color=(0.4, 0.8, 1, 0.5),
            bar_inactive_color=(0.3, 0.3, 0.3, 0.3)
        )
        
        self.gallery_grid = GridLayout(
            cols=2,
            size_hint_y=None,
            spacing=dp(10),
            padding=dp(5)
        )
        self.gallery_grid.bind(minimum_height=self.gallery_grid.setter('height'))
        self.gallery_scroll.add_widget(self.gallery_grid)
        
        main_layout.add_widget(self.gallery_scroll)
        self.add_widget(main_layout)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def on_enter(self):
        self.load_gallery()
    
    def load_gallery(self):
        self.gallery_grid.clear_widgets()
        
        app = MDApp.get_running_app()
        gallery = safe_load_json(GALLERY_FILE, {})
        user_gallery = gallery.get(app.current_user['id'], [])
        
        if not user_gallery:
            empty_label = MDLabel(
                text='No memories yet. Click + to add one!',
                size_hint_y=None,
                height=dp(120),
                halign='center',
                theme_text_color='Custom',
                text_color=(0.6, 0.6, 0.6, 1)
            )
            self.gallery_grid.add_widget(empty_label)
        else:
            for memory in reversed(user_gallery):
                memory_card = self.create_memory_card(memory)
                self.gallery_grid.add_widget(memory_card)
    
    def create_memory_card(self, memory):
        memory_card = MDCard(
            orientation='vertical',
            size_hint_y=None,
            height=dp(220),
            padding=dp(10),
            spacing=dp(8),
            elevation=4,
            radius=[dp(15)],
            md_bg_color=(0.12, 0.12, 0.16, 1)
        )
        
        # Image
        if memory.get('image_path') and os.path.exists(memory['image_path']):
            try:
                img = KivyImage(
                    source=memory['image_path'],
                    size_hint=(1, None),
                    height=dp(130)
                )
                memory_card.add_widget(img)
            except:
                placeholder = MDLabel(
                    text='[Image]',
                    size_hint=(1, None),
                    height=dp(130),
                    halign='center',
                    theme_text_color='Custom',
                    text_color=(0.5, 0.5, 0.5, 1)
                )
                memory_card.add_widget(placeholder)
        else:
            placeholder = MDLabel(
                text='[No Image]',
                size_hint=(1, None),
                height=dp(130),
                halign='center',
                theme_text_color='Custom',
                text_color=(0.5, 0.5, 0.5, 1)
            )
            memory_card.add_widget(placeholder)
        
        # Note preview
        note_text = memory.get('note', 'No description')[:40] + ('...' if len(memory.get('note', '')) > 40 else '')
        note_label = MDLabel(
            text=note_text,
            size_hint=(1, None),
            height=dp(40),
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        memory_card.add_widget(note_label)
        
        # Bottom buttons
        btn_box = BoxLayout(size_hint=(1, None), height=dp(40), spacing=dp(5))
        
        view_btn = MDFlatButton(
            text='VIEW',
            size_hint=(0.5, 1),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        view_btn.bind(on_press=lambda x, m=memory: self.view_memory(m))
        
        delete_btn = MDFlatButton(
            text='DELETE',
            size_hint=(0.5, 1),
            theme_text_color='Custom',
            text_color=(0.9, 0.3, 0.3, 1)
        )
        delete_btn.bind(on_press=lambda x, m=memory: self.delete_memory(m))
        
        btn_box.add_widget(view_btn)
        btn_box.add_widget(delete_btn)
        memory_card.add_widget(btn_box)
        
        # Entrance animation
        memory_card.opacity = 0
        memory_card.scale_value_x = 0.9
        memory_card.scale_value_y = 0.9
        
        anim = Animation(
            opacity=1,
            scale_value_x=1,
            scale_value_y=1,
            duration=0.3,
            t='out_back'
        )
        anim.start(memory_card)
        
        return memory_card
    
    def view_memory(self, memory):
        sound_manager.play('click')
        
        content = MDBoxLayout(
            orientation='vertical',
            spacing=dp(15),
            padding=dp(15),
            adaptive_height=True
        )
        
        # Image
        if memory.get('image_path') and os.path.exists(memory['image_path']):
            try:
                img = KivyImage(
                    source=memory['image_path'],
                    size_hint=(1, None),
                    height=dp(250)
                )
                content.add_widget(img)
            except:
                pass
        
        # Note
        note_scroll = ScrollView(
            size_hint=(1, None),
            height=dp(120),
            bar_width=dp(6),
            bar_color=(0.4, 0.8, 1, 0.5)
        )
        
        note_label = MDLabel(
            text=memory.get('note', 'No description'),
            size_hint_y=None,
            text_size=(Window.width * 0.7, None),
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        note_label.bind(texture_size=note_label.setter('size'))
        note_scroll.add_widget(note_label)
        content.add_widget(note_scroll)
        
        # Date
        date_label = MDLabel(
            text=f"Date: {memory.get('date_display', 'Unknown')}",
            size_hint=(1, None),
            height=dp(30),
            font_style='Caption',
            theme_text_color='Custom',
            text_color=(0.6, 0.6, 0.6, 1)
        )
        content.add_widget(date_label)
        
        dialog = MDDialog(
            title='Memory',
            type='custom',
            content_cls=content,
            size_hint=(0.95, None),
            height=dp(500),
            buttons=[
                MDFlatButton(
                    text="CLOSE",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()
    
    def delete_memory(self, memory):
        sound_manager.play('click')
        
        dialog = MDDialog(
            title='Confirm Delete',
            text='Delete this memory?',
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: dialog.dismiss()
                ),
                MDRaisedButton(
                    text="DELETE",
                    md_bg_color=(0.8, 0.2, 0.2, 1),
                    elevation=4,
                    on_release=lambda x: self.confirm_delete(memory, dialog)
                )
            ]
        )
        dialog.open()
    
    def confirm_delete(self, memory, dialog):
        sound_manager.play('success')
        
        app = MDApp.get_running_app()
        gallery = safe_load_json(GALLERY_FILE, {})
        user_gallery = gallery.get(app.current_user['id'], [])
        
        # Remove from list
        gallery[app.current_user['id']] = [m for m in user_gallery if m.get('id') != memory.get('id')]
        save_json(GALLERY_FILE, gallery)
        
        # Delete image file if exists
        if memory.get('image_path') and os.path.exists(memory['image_path']):
            try:
                os.remove(memory['image_path'])
            except:
                pass
        
        dialog.dismiss()
        self.load_gallery()


class AddMemoryScreen(Screen):
    """Add new memory screen"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.selected_image_path = None
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        layout = BoxLayout(orientation='vertical', padding=dp(15), spacing=dp(15))
        
        # Header
        header = BoxLayout(size_hint=(1, None), height=dp(70))
        
        back_btn = MDIconButton(
            icon='arrow-left',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            on_release=lambda x: setattr(self.manager, 'current', 'gallery')
        )
        
        header_label = MDLabel(
            text='Add Memory',
            font_style='H5',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        header.add_widget(back_btn)
        header.add_widget(header_label)
        header.add_widget(BoxLayout(size_hint=(None, 1), width=dp(48)))
        
        layout.add_widget(header)
        
        # Image preview
        self.image_preview = KivyImage(
            size_hint=(1, None),
            height=dp(250)
        )
        layout.add_widget(self.image_preview)
        
        # Image buttons
        btn_box = BoxLayout(size_hint=(1, None), height=dp(60), spacing=dp(10))
        
        camera_btn = MDRaisedButton(
            text='CAMERA',
            icon='camera',
            size_hint=(0.5, 1),
            md_bg_color=(0.15, 0.55, 0.95, 1),
            elevation=6
        )
        camera_btn.bind(on_press=self.take_photo)
        
        gallery_btn = MDRaisedButton(
            text='SELECT',
            icon='image',
            size_hint=(0.5, 1),
            md_bg_color=(0.6, 0.4, 0.8, 1),
            elevation=6
        )
        gallery_btn.bind(on_press=self.select_photo)
        
        btn_box.add_widget(camera_btn)
        btn_box.add_widget(gallery_btn)
        layout.add_widget(btn_box)
        
        # Note input
        note_scroll = ScrollView(
            size_hint=(1, None),
            height=dp(200),
            bar_width=dp(6),
            bar_color=(0.4, 0.8, 1, 0.5)
        )
        
        self.note_input = MDTextField(
            hint_text='Add a note about this memory...',
            mode='fill',
            multiline=True,
            size_hint=(1, None),
            font_size=sp(15)
        )
        self.note_input.bind(minimum_height=self.note_input.setter('height'))
        note_scroll.add_widget(self.note_input)
        layout.add_widget(note_scroll)
        
        # Save button
        save_btn = MDRaisedButton(
            text='SAVE MEMORY',
            icon='content-save',
            size_hint=(1, None),
            height=dp(60),
            md_bg_color=(0.18, 0.8, 0.44, 1),
            elevation=8,
            font_size=sp(16)
        )
        save_btn.bind(on_press=self.save_memory)
        layout.add_widget(save_btn)
        
        self.add_widget(layout)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def take_photo(self, instance):
        sound_manager.play('click')
        
        # Try to use Android camera
        try:
            from android.permissions import request_permissions, Permission
            from jnius import autoclass
            
            request_permissions([Permission.CAMERA, Permission.WRITE_EXTERNAL_STORAGE])
            
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            Intent = autoclass('android.content.Intent')
            MediaStore = autoclass('android.provider.MediaStore')
            
            intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            PythonActivity.mActivity.startActivityForResult(intent, 1)
            
            show_error_toast("Camera opened! Save to gallery and use SELECT button")
        except:
            show_error_toast("Camera not available. Use SELECT to choose image")
    
    def select_photo(self, instance):
        sound_manager.play('click')
        
        # Try to use Android file picker
        try:
            from android.permissions import request_permissions, Permission
            from android.storage import primary_external_storage_path
            import androidhelper
            
            request_permissions([Permission.READ_EXTERNAL_STORAGE])
            droid = androidhelper.Android()
            result = droid.pick.File()
            
            if result.result:
                self.load_image(result.result)
                return
        except:
            pass
        
        # Fallback file chooser
        from kivy.uix.filechooser import FileChooserListView
        
        pictures_path = '/sdcard/DCIM/Camera/'
        if not os.path.exists(pictures_path):
            pictures_path = '/sdcard/Pictures/'
        if not os.path.exists(pictures_path):
            pictures_path = os.path.expanduser('~')
        
        file_chooser = FileChooserListView(
            path=pictures_path,
            filters=['*.jpg', '*.jpeg', '*.png'],
            size_hint=(1, 1)
        )
        
        content_box = BoxLayout(orientation='vertical', spacing=dp(12))
        content_box.add_widget(file_chooser)
        
        def do_select(instance):
            if file_chooser.selection:
                self.load_image(file_chooser.selection[0])
                chooser_dialog.dismiss()
            else:
                sound_manager.play('error')
                show_error_toast("Please select an image")
        
        chooser_dialog = MDDialog(
            title='Select Image',
            type='custom',
            content_cls=content_box,
            size_hint=(0.95, 0.85),
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: chooser_dialog.dismiss()
                ),
                MDRaisedButton(
                    text="SELECT",
                    md_bg_color=(0.18, 0.8, 0.44, 1),
                    elevation=6,
                    on_release=do_select
                )
            ]
        )
        chooser_dialog.open()
    
    def load_image(self, filepath):
        try:
            self.selected_image_path = filepath
            self.image_preview.source = filepath
            sound_manager.play('success')
        except Exception as e:
            show_error_toast(f"Failed to load image: {str(e)}")
    
    def save_memory(self, instance):
        sound_manager.play('click')
        
        if not self.selected_image_path:
            sound_manager.play('error')
            show_error_toast("Please select an image first")
            return
        
        note = self.note_input.text.strip()
        if not note:
            sound_manager.play('error')
            show_error_toast("Please add a note")
            return
        
        app = MDApp.get_running_app()
        gallery = safe_load_json(GALLERY_FILE, {})
        
        if app.current_user['id'] not in gallery:
            gallery[app.current_user['id']] = []
        
        # Copy image to gallery folder
        new_filename = f"{uuid.uuid4()}.jpg"
        new_path = os.path.join(GALLERY_IMAGES_DIR, new_filename)
        
        try:
            shutil.copy(self.selected_image_path, new_path)
        except Exception as e:
            show_error_toast(f"Failed to save image: {str(e)}")
            return
        
        new_memory = {
            'id': str(uuid.uuid4()),
            'image_path': new_path,
            'note': note,
            'timestamp': datetime.now().isoformat(),
            'date_display': datetime.now().strftime("%B %d, %Y at %I:%M %p")
        }
        
        gallery[app.current_user['id']].append(new_memory)
        save_json(GALLERY_FILE, gallery)
        
        sound_manager.play('success')
        
        # Clear form
        self.selected_image_path = None
        self.image_preview.source = ''
        self.note_input.text = ''
        
        self.manager.current = 'gallery'
