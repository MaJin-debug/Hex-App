"""
screens/splash_screen.py
Splash screen with version display
Version: 1.300X
"""

import os
from kivy.clock import Clock
from kivy.metrics import dp, sp
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image as KivyImage
from kivy.animation import Animation
from kivy.graphics import Color, Rectangle

from kivymd.app import MDApp
from kivymd.uix.label import MDLabel, MDIcon

from utility import LOGO_PATH, load_json, USERS_FILE


class SplashScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        layout = BoxLayout(orientation='vertical', padding=dp(30), spacing=dp(25))
        
        # Logo
        if os.path.exists(LOGO_PATH):
            logo = KivyImage(source=LOGO_PATH, size_hint=(1, 0.5))
        else:
            logo = MDIcon(
                icon='brain',
                font_size=sp(140),
                halign='center',
                size_hint=(1, 0.5),
                theme_text_color='Custom',
                text_color=(0.4, 0.8, 1, 1)
            )
        
        # App name
        app_name = MDLabel(
            text='[b]HEX[/b]',
            markup=True,
            font_style='H2',
            halign='center',
            size_hint=(1, 0.15),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        
        # Tagline
        tagline = MDLabel(
            text='Your Second Brain',
            font_style='H6',
            halign='center',
            size_hint=(1, 0.15),
            theme_text_color='Custom',
            text_color=(0.7, 0.7, 0.7, 1)
        )
        
        # Version
        app = MDApp.get_running_app()
        version_label = MDLabel(
            text=f'Version {app.app_version}',
            font_style='Caption',
            halign='center',
            size_hint=(1, 0.2),
            theme_text_color='Custom',
            text_color=(0.5, 0.5, 0.5, 1)
        )
        
        layout.add_widget(logo)
        layout.add_widget(app_name)
        layout.add_widget(tagline)
        layout.add_widget(version_label)
        self.add_widget(layout)
        
        # Animations
        self.opacity = 0
        logo.scale_value_x = 0.7
        logo.scale_value_y = 0.7
        
        anim = Animation(opacity=1, duration=0.6)
        logo_anim = Animation(scale_value_x=1, scale_value_y=1, duration=0.8, t='out_elastic')
        
        anim.start(self)
        logo_anim.start(logo)
        
        Clock.schedule_once(self.switch_screen, 6)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def switch_screen(self, dt):
        anim = Animation(opacity=0, duration=0.5, t='out_quad')
        anim.bind(on_complete=self._switch)
        anim.start(self)
    
    def _switch(self, *args):
        users = load_json(USERS_FILE, {'users': []})
        
        if users.get('users'):
            self.manager.current = 'login'
        else:
            self.manager.current = 'register'
