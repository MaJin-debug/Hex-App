"""
screens/account_screen.py
Account management screen
Version: 1.300X
"""

from kivy.clock import Clock
from kivy.metrics import dp, sp
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle

from kivymd.app import MDApp
from kivymd.uix.button import MDRaisedButton, MDIconButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel, MDIcon
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.boxlayout import MDBoxLayout

from utility import *


class AccountScreen(Screen):
    """Account details screen"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        scroll = ScrollView()
        layout = MDBoxLayout(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(18),
            adaptive_height=True
        )
        
        # Header
        header = BoxLayout(size_hint=(1, None), height=dp(70))
        
        back_btn = MDIconButton(
            icon='arrow-left',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1),
            on_release=lambda x: setattr(self.manager, 'current', 'chat')
        )
        
        header_label = MDLabel(
            text='Account Details',
            font_style='H5',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        
        header.add_widget(back_btn)
        header.add_widget(header_label)
        header.add_widget(BoxLayout(size_hint=(None, 1), width=dp(48)))
        layout.add_widget(header)
        
        # Input fields
        self.name_input = MDTextField(
            hint_text='Name',
            icon_left='account',
            mode='round',
            size_hint=(1, None),
            height=dp(56),
            font_size=sp(16)
        )
        
        self.mobile_input = MDTextField(
            hint_text='Mobile',
            icon_left='phone',
            mode='round',
            size_hint=(1, None),
            height=dp(56),
            font_size=sp(16)
        )
        
        self.place_input = MDTextField(
            hint_text='Place',
            icon_left='map-marker',
            mode='round',
            size_hint=(1, None),
            height=dp(56),
            font_size=sp(16)
        )
        
        self.password_input = MDTextField(
            hint_text='New Password (optional)',
            icon_left='lock',
            password=True,
            mode='round',
            size_hint=(1, None),
            height=dp(56),
            font_size=sp(16)
        )
        
        # Info card
        info_card = MDCard(
            orientation='horizontal',
            size_hint=(1, None),
            height=dp(65),
            padding=dp(15),
            elevation=2,
            radius=[dp(15)],
            md_bg_color=(0.15, 0.15, 0.2, 1)
        )
        
        info_icon = MDIcon(
            icon='information',
            size_hint=(None, 1),
            width=dp(30),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        
        warning = MDLabel(
            text='Password is for offline use only',
            font_style='Caption',
            theme_text_color='Custom',
            text_color=(0.7, 0.7, 0.7, 1),
            size_hint=(1, 1)
        )
        
        info_card.add_widget(info_icon)
        info_card.add_widget(warning)
        
        layout.add_widget(self.name_input)
        layout.add_widget(self.mobile_input)
        layout.add_widget(self.place_input)
        layout.add_widget(self.password_input)
        layout.add_widget(info_card)
        
        # Save button
        save_btn = MDRaisedButton(
            text='SAVE CHANGES',
            icon='content-save',
            size_hint=(1, None),
            height=dp(60),
            md_bg_color=(0.18, 0.8, 0.44, 1),
            elevation=6,
            font_size=sp(16)
        )
        save_btn.bind(on_press=self.save_account)
        layout.add_widget(save_btn)
        
        scroll.add_widget(layout)
        self.add_widget(scroll)
    
    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
    
    def on_enter(self):
        app = MDApp.get_running_app()
        user = app.current_user
        
        self.name_input.text = user.get('name', '')
        self.mobile_input.text = user.get('mobile', '')
        self.place_input.text = user.get('place', '')
    
    def save_account(self, instance):
        sound_manager.play('click')
        
        app = MDApp.get_running_app()
        users = load_json(USERS_FILE, {'users': []})
        
        for user in users['users']:
            if user['id'] == app.current_user['id']:
                user['name'] = self.name_input.text.strip()
                user['mobile'] = self.mobile_input.text.strip()
                user['place'] = self.place_input.text.strip()
                
                if self.password_input.text.strip():
                    user['password_hash'] = hash_password(self.password_input.text.strip())
                
                app.current_user = user
                break
        
        save_json(USERS_FILE, users)
        sound_manager.play('success')
        
        dialog = MDDialog(
            title='Success',
            text='Account updated successfully!',
            buttons=[
                MDFlatButton(
                    text="OK",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()
        Clock.schedule_once(lambda dt: dialog.dismiss(), 1.5)
