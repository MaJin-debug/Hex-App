"""
screens/chat_screen.py
Main chat interface for HEX app
Version: 1.300X
"""

import os
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.metrics import dp, sp
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.animation import Animation
from kivy.graphics import Color, Rectangle

from kivymd.app import MDApp
from kivymd.uix.button import MDRaisedButton, MDIconButton, MDFlatButton, MDFloatingActionButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog
from kivymd.uix.boxlayout import MDBoxLayout

from utility import *
from calling import *
from custom_widgets import ChatBubble, SuggestionChip

MAX_CHAT_BUBBLES = 30


class ChatScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.hex_knowledge_enabled = True
        self.suggestions_enabled = True
        self.animation_enabled = True
        self.overview_offset = 0
        self.overview_topic = ""
        self.overview_matches = []
        self.chat_bubble_count = 0
        self.awaiting_task_time = False
        self.pending_task_reason = ""
        self.awaiting_note_content = False
        self.pending_note_title = ""
        self.current_button_widget = None
        
        with self.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            self.bg_rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_bg, pos=self._update_bg)
        
        main_layout = BoxLayout(orientation='vertical')
        
        # Header
        header = BoxLayout(size_hint=(1, 0.08), padding=dp(10), spacing=dp(10))
        
        menu_btn = MDIconButton(
            icon='menu',
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1),
            on_release=self.show_menu
        )
        
        self.header_label = MDLabel(
            text='HEX',
            font_style='H6',
            halign='center',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        
        header.add_widget(menu_btn)
        header.add_widget(self.header_label)
        
        # Chat area
        self.chat_scroll = ScrollView(
            size_hint=(1, 0.72),
            bar_width=dp(6),
            bar_color=(0.4, 0.8, 1, 0.5),
            bar_inactive_color=(0.3, 0.3, 0.3, 0.3),
            scroll_type=['bars', 'content']
        )
        self.chat_layout = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            spacing=dp(12),
            padding=[dp(15), dp(15), dp(15), dp(100)]
        )
        self.chat_layout.bind(minimum_height=self.chat_layout.setter('height'))
        self.chat_scroll.add_widget(self.chat_layout)
        
        # Suggestion area - FIXED to single line
        self.suggestion_scroll = ScrollView(
            size_hint=(1, None),
            height=dp(50),
            do_scroll_y=False,
            do_scroll_x=True,
            bar_width=0
        )
        self.suggestion_layout = BoxLayout(
            size_hint_x=None,
            size_hint_y=None,
            height=dp(45),
            spacing=dp(5),
            padding=dp(5)
        )
        self.suggestion_layout.bind(minimum_width=self.suggestion_layout.setter('width'))
        self.suggestion_scroll.add_widget(self.suggestion_layout)
        
        # Input area
        input_container = BoxLayout(
            size_hint=(1, None),
            height=dp(50),
            padding=[dp(10), dp(8)],
            spacing=dp(8)
        )
        
        self.brain_btn = MDIconButton(
            icon='brain',
            size_hint=(None, 1),
            width=dp(50),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        self.brain_btn.bind(on_press=self.toggle_hex_knowledge)
    
        self.animation_btn = MDIconButton(
            icon='animation',
            size_hint=(None, 1),
            width=dp(50),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        self.animation_btn.bind(on_press=self.toggle_animation)
    
        self.input_field = MDTextField(
            hint_text='Ask or teach me...',
            mode='round',
            size_hint=(1, None),
            height=dp(50),
            multiline=False,
            font_size=sp(15),
            cursor_color=(0.4, 0.8, 1, 1)
        )
        self.input_field.bind(text=self.on_text_change)
        self.input_field.bind(on_text_validate=self.send_message)
    
        send_btn = MDIconButton(
            icon='send',
            size_hint=(None, 1),
            width=dp(50),
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        send_btn.bind(on_press=self.send_message)
    
        input_container.add_widget(self.brain_btn)
        input_container.add_widget(self.animation_btn)
        input_container.add_widget(self.input_field)
        input_container.add_widget(send_btn)
        
        # FAB
        self.fab = MDFloatingActionButton(
            icon='database-plus',
            pos_hint={'center_x': 0.9, 'center_y': 0.10},
            md_bg_color=(0.15, 0.55, 0.95, 1),
            elevation=8
        )
        self.fab.bind(on_press=lambda x: setattr(self.manager, 'current', 'add_knowledge'))
        
        main_layout.add_widget(header)
        main_layout.add_widget(self.chat_scroll)
        main_layout.add_widget(self.suggestion_scroll)
        main_layout.add_widget(input_container)
        
        self.add_widget(main_layout)
        self.add_widget(self.fab)
        
        Clock.schedule_interval(self.check_tasks, 60)
    
    def _update_bg(self, *args):
        self.bg_rect.size = self.size
        self.bg_rect.pos = self.pos
    
    def remove_current_button(self):
        if self.current_button_widget and self.current_button_widget in self.chat_layout.children:
            anim = Animation(opacity=0, duration=0.2)
            anim.bind(on_complete=lambda *args: self._remove_widget(self.current_button_widget))
            anim.start(self.current_button_widget)
    
    def _remove_widget(self, widget):
        if widget in self.chat_layout.children:
            self.chat_layout.remove_widget(widget)
            self.chat_bubble_count -= 1
        self.current_button_widget = None
    
    def on_enter(self):
        app = MDApp.get_running_app()
        user_name = app.current_user['name'].upper()
        self.header_label.text = f"HEX - {user_name}"
        
        self.fab.opacity = 0
        self.fab.scale_value_x = 0.5
        self.fab.scale_value_y = 0.5
        anim = Animation(
            opacity=1,
            scale_value_x=1,
            scale_value_y=1,
            duration=0.4,
            t='out_back'
        )
        anim.start(self.fab)
        
        if len(self.chat_layout.children) == 0:
            from calling import TutorialManager
            if TutorialManager.is_first_time(app.current_user['id']):
                self.show_tutorial()
                TutorialManager.mark_tutorial_complete(app.current_user['id'])
            else:
                from calling import DataCaller
                greeting = DataCaller.get_greeting()
                self.add_chat_bubble(
                    f"{greeting}, {app.current_user['name']}!",
                    is_user=False,
                    animate=True
                )
        
        self.check_tasks(None)
    
    def process_dynamic_content(self, text):
        from calling import DataCaller
        from datetime import datetime
        app = MDApp.get_running_app()
    
        replacements = {
            '{user_name}': DataCaller.get_user_name(app.current_user),
            '{current_date}': DataCaller.get_current_date(),
            '{current_time}': DataCaller.get_current_time(),
            '{greeting}': DataCaller.get_greeting(),
            '{current_year}': str(datetime.now().year),
            '{current_month}': datetime.now().strftime("%B"),
            '{current_day}': str(datetime.now().day),
            '{day_of_week}': datetime.now().strftime("%A"),
        }
        
        for placeholder, value in replacements.items():
            text = text.replace(placeholder, value)
    
        return text
    
    def show_tutorial(self):
        from calling import TutorialManager
        app = MDApp.get_running_app()
        bubbles = TutorialManager.get_tutorial_bubbles(app.current_user['name'])
        
        for i, bubble_data in enumerate(bubbles):
            Clock.schedule_once(
                lambda dt, b=bubble_data: self.add_chat_bubble(
                    b['message'],
                    is_user=b['is_user'],
                    animate=b['animate']
                ),
                i * 1.8
            )
    
    def check_tasks(self, dt):
        from calling import TaskChecker
        app = MDApp.get_running_app()
        pending = TaskChecker.get_pending_tasks(app.current_user['id'])
        
        for task in pending:
            self.add_chat_bubble(
                f"Reminder: {task['reason']}",
                is_user=False,
                animate=True
            )
            TaskChecker.mark_task_notified(app.current_user['id'], task['id'])
            
            self.remove_current_button()
            
            complete_btn = MDRaisedButton(
                text='MARK COMPLETE',
                size_hint_y=None,
                height=dp(50),
                md_bg_color=(0.18, 0.8, 0.44, 1),
                icon='check',
                elevation=4
            )
            complete_btn.bind(on_press=lambda x, t=task: self.complete_task(t))
            
            complete_btn.opacity = 0
            self.chat_layout.add_widget(complete_btn)
            anim = Animation(opacity=1, duration=0.3)
            anim.start(complete_btn)
            
            self.current_button_widget = complete_btn
            self.chat_bubble_count += 1
    
    def complete_task(self, task):
        from calling import TaskChecker
        sound_manager.play('success')
        app = MDApp.get_running_app()
        TaskChecker.mark_task_completed(app.current_user['id'], task['id'])
        self.remove_current_button()
        self.add_chat_bubble("Task completed!", is_user=False, animate=True)
    
    def toggle_hex_knowledge(self, instance):
        sound_manager.play('click')
        self.hex_knowledge_enabled = not self.hex_knowledge_enabled
        
        target_color = (0.4, 0.8, 1, 1) if self.hex_knowledge_enabled else (0.5, 0.5, 0.5, 0.6)
        
        anim = Animation(text_color=target_color, duration=0.3, t='out_quad')
        anim.start(self.brain_btn)
    
    def toggle_animation(self, instance):
        sound_manager.play('click')
        self.animation_enabled = not self.animation_enabled
        
        target_color = (0.4, 0.8, 1, 1) if self.animation_enabled else (0.5, 0.5, 0.5, 0.6)
        
        anim = Animation(text_color=target_color, duration=0.3, t='out_quad')
        anim.start(self.animation_btn)
    
    def on_text_change(self, instance, value):
        if len(value) >= 1:
            self.update_suggestions(value)
        else:
            self.suggestion_layout.clear_widgets()
    
    def add_chat_bubble(self, message, is_user=True, is_sure=None, animate=False):
        if self.chat_bubble_count >= MAX_CHAT_BUBBLES:
            children = [child for child in self.chat_layout.children if isinstance(child, ChatBubble)]
            if children:
                oldest = children[-1]
                self.chat_layout.remove_widget(oldest)
                self.chat_bubble_count -= 1
        
        should_animate = animate and self.animation_enabled
        
        if not is_user and should_animate:
            line_count = message.count('\n') + 1
            
            if line_count >= 15:
                remembering_bubble = ChatBubble("Remembering.....", is_user=False, is_sure=None, animate=False)
                self.chat_layout.add_widget(remembering_bubble)
                Clock.schedule_once(
                    lambda dt: self._replace_remembering(remembering_bubble, message, is_user, is_sure, True),
                    0.9
                )
            else:
                bubble = ChatBubble(message, is_user=is_user, is_sure=is_sure, animate=True)
                self.chat_layout.add_widget(bubble)
                self.chat_bubble_count += 1
                Clock.schedule_once(lambda dt: self._scroll_to_bottom(), 0.2)
        else:
            bubble = ChatBubble(message, is_user=is_user, is_sure=is_sure, animate=False)
            self.chat_layout.add_widget(bubble)
            self.chat_bubble_count += 1
            Clock.schedule_once(lambda dt: self._scroll_to_bottom(), 0.15)
    
    def _replace_remembering(self, remembering_bubble, message, is_user, is_sure, animate):
        self.chat_layout.remove_widget(remembering_bubble)
        bubble = ChatBubble(message, is_user=is_user, is_sure=is_sure, animate=animate)
        self.chat_layout.add_widget(bubble)
        self.chat_bubble_count += 1
        Clock.schedule_once(lambda dt: self._scroll_to_bottom(), 0.2)
    
    def _scroll_to_bottom(self):
        anim = Animation(scroll_y=0, duration=0.35, t='out_cubic')
        anim.start(self.chat_scroll)
    
    def send_message(self, instance):
        sound_manager.play('click')
        user_input = self.input_field.text.strip()
        
        if not user_input:
            return
        
        self.remove_current_button()
        
        if self.awaiting_task_time:
            self.handle_task_time(user_input)
            return
        
        if self.awaiting_note_content:
            self.handle_note_content(user_input)
            return
        
        # Commands
        if user_input.lower() == '/teach':
            self.manager.current = 'add_knowledge'
            self.input_field.text = ''
            return
        
        if user_input.lower() == '/bye':
            self.goodbye_sequence()
            return
        
        if user_input.lower().startswith('/overview'):
            topic = user_input[9:].strip()
            self.show_overview(topic)
            self.input_field.text = ''
            return
        
        if user_input.lower() == '/add_note':
            self.start_note_creation()
            self.input_field.text = ''
            return
        
        if user_input.lower().startswith('/remind'):
            reason = user_input[7:].strip()
            self.start_reminder_creation(reason)
            self.input_field.text = ''
            return
        
        if user_input.lower().startswith('/memory'):
            topic = user_input[7:].strip()
            self.show_memory(topic)
            self.input_field.text = ''
            return
        
        self.add_chat_bubble(user_input, is_user=True, animate=False)
        self.process_query(user_input)
        
        self.input_field.text = ''
        self.suggestion_layout.clear_widgets()
    
    def show_memory(self, topic):
        """Show memories from gallery based on topic"""
        app = MDApp.get_running_app()
        gallery = safe_load_json(GALLERY_FILE, {})
        user_gallery = gallery.get(app.current_user['id'], [])
        
        if not user_gallery:
            self.add_chat_bubble("No memories found. Add some in Gallery!", is_user=False, animate=True)
            return
        
        if not topic:
            self.add_chat_bubble("Please specify what memory you want to see", is_user=False, animate=True)
            return
        
        # Search for matching memories
        topic_words = set(topic.lower().split())
        matching_memories = []
        
        for mem in user_gallery:
            note_words = set(mem.get('note', '').lower().split())
            if topic_words & note_words:
                matching_memories.append(mem)
        
        if matching_memories:
            for mem in matching_memories[:3]:  # Show first 3
                memory_text = f"Memory: {mem.get('note', 'No description')}\nDate: {mem.get('date_display', 'Unknown')}"
                self.add_chat_bubble(memory_text, is_user=False, is_sure=True, animate=True)
        else:
            self.add_chat_bubble(f"No memories found for: {topic}", is_user=False, animate=True)
    
    def process_query(self, query):
        app = MDApp.get_running_app()
        user_id = app.current_user['id']
        
        user_knowledge = safe_load_json(
            os.path.join(DATA_DIR, f'knowledge_user_{user_id}.json'),
            {'knowledge': []}
        )
        hex_knowledge = safe_load_json(HEX_KNOWLEDGE_FILE, {'knowledge': []})
        spelling_map = safe_load_json(SPELLING_MAP_FILE, {})
        spelling_rejected = safe_load_json(SPELLING_REJECTED_FILE, {})
        
        normalized_query = query.lower().strip()
        
        words = normalized_query.split()
        corrected_words = []
        for word in words:
            if word in spelling_map:
                corrected_words.append(spelling_map[word])
            else:
                corrected_words.append(word)
        corrected_query = ' '.join(corrected_words)
        
        all_knowledge = user_knowledge['knowledge'][:]
        if self.hex_knowledge_enabled:
            all_knowledge.extend(hex_knowledge['knowledge'])
        
        exact_match = self.find_exact_match(corrected_query, all_knowledge)
        if exact_match:
            question, answer, sure = exact_match
            self.add_chat_bubble(answer, is_user=False, is_sure=sure, animate=True)
            return
        
        fuzzy_match = self.find_fuzzy_match(corrected_query, all_knowledge)
        if fuzzy_match:
            question, answer, sure = fuzzy_match
            
            reject_key = f"{normalized_query}||{question.lower()}"
            if reject_key not in spelling_rejected:
                self.add_chat_bubble(answer, is_user=False, is_sure=sure, animate=True)
                Clock.schedule_once(
                    lambda dt: self.show_spelling_buttons(query, question, reject_key),
                    1.5
                )
                return
        
        keyword_match = self.find_keyword_match(corrected_query, all_knowledge)
        if keyword_match:
            question, answer, sure = keyword_match
            
            reject_key = f"{normalized_query}||{question.lower()}"
            if reject_key not in spelling_rejected:
                self.add_chat_bubble(answer, is_user=False, is_sure=sure, animate=True)
                Clock.schedule_once(
                    lambda dt: self.show_spelling_buttons(query, question, reject_key),
                    1.5
                )
                return
        
        self.add_chat_bubble(
            "I don't know about that yet. Would you like to teach me?",
            is_user=False,
            animate=True
        )
        
        Clock.schedule_once(lambda dt: self._add_store_button(query), 1.2)
    
    def _add_store_button(self, query):
        self.remove_current_button()
        
        teach_btn = MDRaisedButton(
            text='STORE THIS',
            size_hint_y=None,
            height=dp(52),
            md_bg_color=(0.18, 0.8, 0.44, 1),
            icon='database-plus',
            elevation=6
        )
        teach_btn.bind(on_press=lambda x: self.quick_teach(query))
        
        teach_btn.opacity = 0
        self.chat_layout.add_widget(teach_btn)
        
        anim = Animation(opacity=1, duration=0.3, t='out_quad')
        anim.start(teach_btn)
        
        self.current_button_widget = teach_btn
        self.chat_bubble_count += 1
        Clock.schedule_once(lambda dt: self._scroll_to_bottom(), 0.25)
    
    def find_exact_match(self, query, knowledge_list):
        for item in knowledge_list:
            if item['question'].lower() == query:
                answer = self.process_dynamic_content(item['answer'])
                return (item['question'], answer, item.get('sure', False))
        return None
    
    def find_fuzzy_match(self, query, knowledge_list):
        for item in knowledge_list:
            if fuzzy_match(query, item['question'].lower(), threshold=0.8):
                if item['question'].lower() != query:
                    answer = self.process_dynamic_content(item['answer'])
                    return (item['question'], answer, item.get('sure', False))
        return None
    
    def find_keyword_match(self, query, knowledge_list):
        query_words = set(query.split())
        for item in knowledge_list:
            question_words = set(item['question'].lower().split())
            if query_words & question_words:
                overlap = len(query_words & question_words) / len(query_words)
                if overlap >= 0.5:
                    if item['question'].lower() != query and not fuzzy_match(query, item['question'].lower(), threshold=0.8):
                        answer = self.process_dynamic_content(item['answer'])
                        return (item['question'], answer, item.get('sure', False))
        return None

    def show_spelling_buttons(self, original, matched, reject_key):
        self.remove_current_button()
        
        button_box = BoxLayout(
            size_hint_y=None,
            height=dp(110),
            padding=dp(12),
            spacing=dp(12),
            orientation='vertical'
        )
        
        question_label = MDLabel(
            text=f'Did you mean "{matched}" when you said "{original}"?',
            size_hint=(1, 0.5),
            halign='center',
            markup=True,
            theme_text_color='Custom',
            text_color=(0.9, 0.9, 0.9, 1)
        )
        button_box.add_widget(question_label)
        
        buttons_row = BoxLayout(size_hint=(1, 0.5), spacing=dp(12))
        
        yes_btn = MDRaisedButton(
            text='YES',
            size_hint=(0.5, 1),
            md_bg_color=(0.18, 0.8, 0.44, 1),
            icon='check',
            elevation=4
        )
        yes_btn.bind(on_press=lambda x: self.handle_spelling_yes(
            original.lower(), matched.lower(), reject_key
        ))
        
        no_btn = MDRaisedButton(
            text='NO',
            size_hint=(0.5, 1),
            md_bg_color=(0.8, 0.2, 0.2, 1),
            icon='close',
            elevation=4
        )
        no_btn.bind(on_press=lambda x: self.handle_spelling_no(
            original, reject_key
        ))
        
        buttons_row.add_widget(yes_btn)
        buttons_row.add_widget(no_btn)
        button_box.add_widget(buttons_row)
        
        button_box.opacity = 0
        self.chat_layout.add_widget(button_box)
        
        anim = Animation(opacity=1, duration=0.3)
        anim.start(button_box)
        
        self.current_button_widget = button_box
        self.chat_bubble_count += 1
        
        Clock.schedule_once(lambda dt: self._scroll_to_bottom(), 0.25)

    def handle_spelling_yes(self, original_query, matched_question, reject_key):
        sound_manager.play('success')
        
        self.remove_current_button()
        
        spelling_map = safe_load_json(SPELLING_MAP_FILE, {})
        
        original_words = original_query.lower().split()
        matched_words = matched_question.lower().split()
        
        for orig_word in original_words:
            if orig_word not in spelling_map:
                best_match = None
                best_score = 0.0
                
                for match_word in matched_words:
                    if orig_word != match_word:
                        score = fuzzy_similarity(orig_word, match_word)
                        if score > best_score and score >= 0.5:
                            best_score = score
                            best_match = match_word
                
                if best_match:
                    spelling_map[orig_word] = best_match
        
        success = safe_save_json(SPELLING_MAP_FILE, spelling_map)
        
        if success:
            self.add_chat_bubble('Learned spelling variation!', is_user=False, is_sure=True, animate=True)
        else:
            sound_manager.play('error')
            show_error_toast("Failed to save spelling variation")
        
        from utility import data_cache
        data_cache.invalidate(SPELLING_MAP_FILE)

    def handle_spelling_no(self, original, reject_key):
        sound_manager.play('click')
        
        self.remove_current_button()
        
        spelling_rejected = safe_load_json(SPELLING_REJECTED_FILE, {})
        spelling_rejected[reject_key] = True
        
        if not safe_save_json(SPELLING_REJECTED_FILE, spelling_rejected):
            show_error_toast("Failed to save rejection")
        
        self.add_chat_bubble(
            'Do you want to store this as new knowledge?',
            is_user=False,
            animate=True
        )
        
        store_box = BoxLayout(
            size_hint_y=None,
            height=dp(65),
            padding=dp(12),
            spacing=dp(12)
        )
        
        store_yes_btn = MDRaisedButton(
            text='YES - STORE IT',
            size_hint=(0.5, 1),
            md_bg_color=(0.18, 0.8, 0.44, 1),
            icon='database-plus',
            elevation=4
        )
        store_yes_btn.bind(on_press=lambda x: self.store_new_knowledge(original))
        
        store_no_btn = MDRaisedButton(
            text='NO',
            size_hint=(0.5, 1),
            md_bg_color=(0.5, 0.5, 0.5, 1),
            icon='close',
            elevation=4
        )
        store_no_btn.bind(on_press=lambda x: self.dismiss_store_box())
        
        store_box.add_widget(store_yes_btn)
        store_box.add_widget(store_no_btn)
        
        store_box.opacity = 0
        self.chat_layout.add_widget(store_box)
        
        anim = Animation(opacity=1, duration=0.3)
        anim.start(store_box)
        
        self.current_button_widget = store_box
        self.chat_bubble_count += 1
        Clock.schedule_once(lambda dt: self._scroll_to_bottom(), 0.25)

    def store_new_knowledge(self, question):
        sound_manager.play('click')
        self.remove_current_button()
        
        app = MDApp.get_running_app()
        app.pending_teach_question = question
        self.manager.current = 'add_knowledge'

    def dismiss_store_box(self):
        sound_manager.play('click')
        self.remove_current_button()
        self.add_chat_bubble('Okay!', is_user=False, animate=True)
    
    def quick_teach(self, question):
        sound_manager.play('click')
        self.remove_current_button()
        app = MDApp.get_running_app()
        app.pending_teach_question = question
        self.manager.current = 'add_knowledge'
    
    def update_suggestions(self, value):
        self.suggestion_layout.clear_widgets()
        
        if not self.suggestions_enabled:
            return
        
        if value.startswith('/'):
            commands = ['/teach', '/overview', '/add_note', '/remind', '/memory', '/bye']
            for cmd in commands:
                if cmd.startswith(value.lower()):
                    chip = SuggestionChip(
                        text=cmd,
                        on_press_callback=lambda x, c=cmd: self.use_suggestion(c)
                    )
                    self.suggestion_layout.add_widget(chip)
            return
        
        app = MDApp.get_running_app()
        user_id = app.current_user['id']
        
        user_knowledge = safe_load_json(
            os.path.join(DATA_DIR, f'knowledge_user_{user_id}.json'),
            {'knowledge': []}
        )
        hex_knowledge = safe_load_json(HEX_KNOWLEDGE_FILE, {'knowledge': []})
        
        suggestions = []
        
        for item in user_knowledge['knowledge']:
            if value.lower() in item['question'].lower():
                suggestions.append(item['question'])
        
        if len(suggestions) < 5 and self.hex_knowledge_enabled:
            for item in hex_knowledge['knowledge']:
                if value.lower() in item['question'].lower():
                    if item['question'] not in suggestions:
                        suggestions.append(item['question'])
        
        for suggestion in suggestions[:5]:
            # Truncate long suggestions
            display_text = suggestion if len(suggestion) <= 35 else suggestion[:32] + '...'
            chip = SuggestionChip(
                text=display_text,
                on_press_callback=lambda x, s=suggestion: self.use_suggestion(s)
            )
            self.suggestion_layout.add_widget(chip)
    
    def use_suggestion(self, suggestion):
        sound_manager.play('click')
        self.input_field.text = suggestion
        self.input_field.focus = True
    
    def show_overview(self, topic):
        from calling import NoteManager
        
        if not topic:
            self.add_chat_bubble(
                'Please specify a topic: /overview <topic>',
                is_user=False,
                animate=True
            )
            return
        
        app = MDApp.get_running_app()
        user_id = app.current_user['id']
        
        user_knowledge = safe_load_json(
            os.path.join(DATA_DIR, f'knowledge_user_{user_id}.json'),
            {'knowledge': []}
        )
        hex_knowledge = safe_load_json(HEX_KNOWLEDGE_FILE, {'knowledge': []})
        notes = NoteManager.get_notes(user_id)
        
        # Get gallery memories
        gallery = safe_load_json(GALLERY_FILE, {})
        user_gallery = gallery.get(user_id, [])
        
        all_knowledge = user_knowledge['knowledge'] + (
            hex_knowledge['knowledge'] if self.hex_knowledge_enabled else []
        )
        
        related = []
        topic_words = set(topic.lower().split())
        
        for item in all_knowledge:
            if not item.get('sure', False):
                continue
            
            question_words = set(item['question'].lower().split())
            answer_words = set(item['answer'].lower().split())
            
            if topic_words & (question_words | answer_words):
                related.append(('knowledge', item['question'], item['answer']))
        
        for note in notes:
            title_words = set(note['title'].lower().split())
            content_words = set(note['content'].lower().split())
            
            if topic_words & (title_words | content_words):
                related.append(('note', note['title'], note['content']))
        
        for mem in user_gallery:
            note_words = set(mem.get('note', '').lower().split())
            if topic_words & note_words:
                related.append(('memory', mem.get('note', ''), mem.get('date_display', '')))
        
        if related:
            self.overview_topic = topic
            self.overview_matches = related
            self.overview_offset = 0
            self.display_overview_page()
        else:
            self.add_chat_bubble(
                f'No information found for "{topic}"',
                is_user=False,
                animate=True
            )
    
    def display_overview_page(self):
        start = self.overview_offset
        end = min(start + 5, len(self.overview_matches))
        
        overview_text = f"Overview: {self.overview_topic}\n\n"
        
        for i, (type, title, content) in enumerate(self.overview_matches[start:end], start + 1):
            words = content.split()
            short_content = ' '.join(words[:20])
            if len(words) > 20:
                short_content += '...'
            
            if type == 'note':
                overview_text += f"{i}. [Note] {title}\n   {short_content}\n\n"
            elif type == 'memory':
                overview_text += f"{i}. [Memory] {title}\n   Date: {short_content}\n\n"
            else:
                overview_text += f"{i}. Q: {title}\n   A: {short_content}\n\n"
        
        total = len(self.overview_matches)
        remaining = total - end
        
        if remaining > 0:
            overview_text += f"\n{remaining} more matches available."
        
        self.add_chat_bubble(overview_text, is_user=False, is_sure=True, animate=True)
        
        if remaining > 0:
            Clock.schedule_once(lambda dt: self.add_next_button(), 1.5)
    
    def add_next_button(self):
        self.remove_current_button()
        
        next_btn = MDRaisedButton(
            text='SHOW NEXT 5',
            size_hint_y=None,
            height=dp(52),
            md_bg_color=(0.15, 0.55, 0.95, 1),
            icon='arrow-right',
            elevation=6
        )
        next_btn.bind(on_press=lambda x: self.show_next_overview())
        
        next_btn.opacity = 0
        self.chat_layout.add_widget(next_btn)
        
        anim = Animation(opacity=1, duration=0.3)
        anim.start(next_btn)
        
        self.current_button_widget = next_btn
        self.chat_bubble_count += 1
        Clock.schedule_once(lambda dt: self._scroll_to_bottom(), 0.25)
    
    def show_next_overview(self):
        sound_manager.play('click')
        self.remove_current_button()
        self.overview_offset += 5
        self.display_overview_page()
    
    def start_note_creation(self):
        self.add_chat_bubble("What's the title of your note?", is_user=False, animate=True)
        self.awaiting_note_content = True
        self.pending_note_title = ""
    
    def handle_note_content(self, user_input):
        from calling import NoteManager
        
        if not self.pending_note_title:
            self.pending_note_title = user_input
            self.add_chat_bubble(
                f"Title: {user_input}\n\nNow enter the note content:",
                is_user=False,
                animate=True
            )
            self.input_field.text = ''
        else:
            app = MDApp.get_running_app()
            NoteManager.add_note(app.current_user['id'], self.pending_note_title, user_input)
            sound_manager.play('success')
            self.add_chat_bubble("Note saved!", is_user=False, animate=True)
            self.awaiting_note_content = False
            self.pending_note_title = ""
            self.input_field.text = ''
    
    def start_reminder_creation(self, reason):
        if not reason:
            self.add_chat_bubble("What should I remind you about?", is_user=False, animate=True)
            self.awaiting_task_time = True
            self.pending_task_reason = ""
        else:
            self.add_chat_bubble(
                f"Reminder: {reason}\n\nWhen? (e.g., 5pm, in 2 hours)",
                is_user=False,
                animate=True
            )
            self.awaiting_task_time = True
            self.pending_task_reason = reason
    
    def handle_task_time(self, user_input):
        from calling import TaskChecker
        
        if not self.pending_task_reason:
            self.pending_task_reason = user_input
            self.add_chat_bubble(
                f"When should I remind you about: {user_input}?",
                is_user=False,
                animate=True
            )
            self.input_field.text = ''
        else:
            app = MDApp.get_running_app()
            success, message = TaskChecker.create_task(
                app.current_user['id'],
                self.pending_task_reason,
                user_input
            )
            
            if success:
                sound_manager.play('success')
            else:
                sound_manager.play('error')
            
            self.add_chat_bubble(message, is_user=False, animate=True)
            self.awaiting_task_time = False
            self.pending_task_reason = ""
            self.input_field.text = ''
    
    def goodbye_sequence(self):
        app = MDApp.get_running_app()
        user_name = app.current_user['name'].upper()
        
        goodbye_screen = Screen(name='goodbye')
        
        with goodbye_screen.canvas.before:
            Color(0.08, 0.08, 0.12, 1)
            rect = Rectangle(size=Window.size, pos=(0, 0))
        
        layout = BoxLayout(orientation='vertical')
        goodbye_label = MDLabel(
            text=f'BYE, {user_name}!',
            font_style='H3',
            halign='center',
            valign='center',
            theme_text_color='Custom',
            text_color=(0.4, 0.8, 1, 1)
        )
        layout.add_widget(goodbye_label)
        goodbye_screen.add_widget(layout)
        
        self.manager.add_widget(goodbye_screen)
        self.manager.current = 'goodbye'
        
        goodbye_label.opacity = 0
        goodbye_label.scale_value_x = 0.5
        goodbye_label.scale_value_y = 0.5
        
        anim = Animation(
            opacity=1,
            scale_value_x=1,
            scale_value_y=1,
            duration=1,
            t='out_elastic'
        )
        anim.start(goodbye_label)
        
        Clock.schedule_once(lambda dt: app.stop(), 2.5)
    
    def show_menu(self, instance):
        sound_manager.play('click')
        
        content = MDBoxLayout(
            orientation='vertical',
            spacing=dp(12),
            padding=dp(15),
            adaptive_height=True
        )
        
        menu_items = [
            ('database-plus', 'Store Knowledge', 'add_knowledge', (0.18, 0.8, 0.44, 1)),
            ('notebook', 'My Notes', 'notes', (1, 0.6, 0, 1)),
            ('camera-image', 'Gallery', 'gallery', (1, 0.4, 0.6, 1)),
            ('cog', 'Settings', 'settings', (0.15, 0.55, 0.95, 1)),
            ('account', 'Account', 'account', (0.6, 0.4, 0.8, 1))
        ]
        
        for icon, text, action, color in menu_items:
            btn = MDRaisedButton(
                text=text,
                icon=icon,
                size_hint_y=None,
                height=dp(56),
                md_bg_color=color,
                elevation=4
            )
            btn.bind(on_press=lambda x, a=action: self.menu_action(a))
            content.add_widget(btn)
        
        self.menu_dialog = MDDialog(
            title='Menu',
            type='custom',
            content_cls=content,
            buttons=[
                MDFlatButton(
                    text="CLOSE",
                    theme_text_color='Custom',
                    text_color=(0.4, 0.8, 1, 1),
                    on_release=lambda x: self.menu_dialog.dismiss()
                )
            ]
        )
        self.menu_dialog.open()
    
    def menu_action(self, action):
        sound_manager.play('click')
        self.menu_dialog.dismiss()
        
        if action == 'add_knowledge':
            self.manager.current = 'add_knowledge'
        elif action == 'notes':
            self.manager.current = 'notes'
        elif action == 'gallery':
            self.manager.current = 'gallery'
        elif action == 'settings':
            self.manager.current = 'settings'
        elif action == 'account':
            self.manager.current = 'account'
